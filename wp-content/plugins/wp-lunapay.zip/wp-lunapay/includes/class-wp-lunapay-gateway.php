﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce MoonPay Payment Gateway.
 */
class WP_LunaPay_Gateway extends WC_Payment_Gateway {

	private WP_LunaPay_API $api;

	public function __construct() {
		$this->id                 = 'moonpay';
		$this->has_fields         = false;
		$this->method_title       = __( 'MoonPay', 'wp-lunapay' );
		$this->method_description = __( 'Let customers pay with cryptocurrency via the MoonPay widget. Funds are converted and settled to your account.', 'wp-lunapay' );
		$this->order_button_text  = __( 'Pay with Crypto (MoonPay)', 'wp-lunapay' );
		$this->icon               = WP_LUNAPAY_PLUGIN_URL . 'assets/images/moonpay-logo.svg';
		$this->supports           = [ 'products', 'refunds' ];

		$this->init_form_fields();
		$this->init_settings();

		// Map settings to properties
		$this->title             = $this->get_option( 'title' );
		$this->description       = $this->get_option( 'description' );
		$this->enabled           = $this->get_option( 'enabled' );
		$this->order_button_text = $this->get_option( 'button_text', __( 'Pay with Crypto (MoonPay)', 'wp-lunapay' ) );

		// Show/hide checkout icon based on setting
		if ( $this->get_option( 'show_icon', 'yes' ) !== 'yes' ) {
			$this->icon = '';
		}

		$this->api = $this->make_api();

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'validate_api_keys' ] );
		add_action( 'woocommerce_receipt_' . $this->id, [ $this, 'receipt_page' ] );
		add_action( 'woocommerce_thankyou_' . $this->id, [ $this, 'thankyou_page' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
	}

	// -------------------------------------------------------------------------
	// Admin settings fields
	// -------------------------------------------------------------------------

	public function init_form_fields(): void {
		$this->form_fields = [
			'enabled'               => [
				'title'   => __( 'Enable/Disable', 'wp-lunapay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable MoonPay Gateway', 'wp-lunapay' ),
				'default' => 'no',
			],
			'title'                 => [
				'title'       => __( 'Title', 'wp-lunapay' ),
				'type'        => 'text',
				'description' => __( 'Payment method title shown at checkout.', 'wp-lunapay' ),
				'default'     => __( 'Pay with Cryptocurrency', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'description'           => [
				'title'       => __( 'Description', 'wp-lunapay' ),
				'type'        => 'textarea',
				'description' => __( 'Description shown below the payment method title at checkout.', 'wp-lunapay' ),
				'default'     => __( 'Securely pay with Bitcoin, Ethereum, and 100+ cryptocurrencies via MoonPay.', 'wp-lunapay' ),
			],
			'sandbox'               => [
				'title'   => __( 'Sandbox Mode', 'wp-lunapay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable sandbox (test) mode', 'wp-lunapay' ),
				'default' => 'yes',
			],
			'publishable_key'       => [
				'title'       => __( 'Publishable Key', 'wp-lunapay' ),
				'type'        => 'text',
				'description' => __( 'Your MoonPay publishable API key.', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'secret_key'            => [
				'title'       => __( 'Secret Key', 'wp-lunapay' ),
				'type'        => 'password',
				'description' => __( 'Your MoonPay secret API key. Never share this.', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'default_crypto'        => [
				'title'       => __( 'Default Cryptocurrency', 'wp-lunapay' ),
				'type'        => 'text',
				'description' => __( 'Default crypto currency code pre-selected in the widget (e.g. eth, btc, usdc_polygon).', 'wp-lunapay' ),
				'default'     => 'eth',
				'desc_tip'    => true,
			],
			'allowed_cryptos'       => [
				'title'       => __( 'Allowed Cryptocurrencies', 'wp-lunapay' ),
				'type'        => 'textarea',
				'description' => __( 'Comma-separated list of allowed crypto currency codes. Leave empty to allow all.', 'wp-lunapay' ),
				'default'     => 'eth,btc,usdc,usdc_polygon',
				'desc_tip'    => true,
			],
			'widget_mode'           => [
				'title'       => __( 'Widget Display Mode', 'wp-lunapay' ),
				'type'        => 'select',
				'options'     => [
					'redirect' => __( 'Redirect to MoonPay', 'wp-lunapay' ),
					'iframe'   => __( 'Embedded iFrame', 'wp-lunapay' ),
					'popup'    => __( 'Modal Popup', 'wp-lunapay' ),
				],
				'default'     => 'redirect',
				'description' => __( 'How to display the MoonPay payment widget.', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'iframe_height'         => [
				'title'       => __( 'iFrame Height (px)', 'wp-lunapay' ),
				'type'        => 'number',
				'description' => __( 'Height of the embedded iFrame or popup in pixels. Only applies to iFrame and Popup modes.', 'wp-lunapay' ),
				'default'     => '620',
				'custom_attributes' => [ 'min' => '300', 'max' => '1200', 'step' => '10' ],
				'desc_tip'    => true,
			],
			'color_code'            => [
				'title'       => __( 'Widget Accent Color', 'wp-lunapay' ),
				'type'        => 'color',
				'description' => __( 'Hex color used as the MoonPay widget accent color.', 'wp-lunapay' ),
				'default'     => '#7B3FE4',
				'desc_tip'    => true,
			],
			'show_icon'             => [
				'title'   => __( 'Show Payment Icon', 'wp-lunapay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Show the MoonPay logo next to the payment method at checkout', 'wp-lunapay' ),
				'default' => 'yes',
			],
			'button_text'           => [
				'title'       => __( 'Order Button Text', 'wp-lunapay' ),
				'type'        => 'text',
				'description' => __( 'Text on the "Place Order" button when MoonPay is selected.', 'wp-lunapay' ),
				'default'     => __( 'Pay with Crypto (MoonPay)', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'amount_section'        => [
				'title' => __( 'Order Amount Limits', 'wp-lunapay' ),
				'type'  => 'title',
			],
			'min_order_amount'      => [
				'title'             => __( 'Minimum Order Amount', 'wp-lunapay' ),
				'type'              => 'number',
				'description'       => __( 'Minimum order total (in store currency) to show MoonPay at checkout. Leave 0 for no minimum.', 'wp-lunapay' ),
				'default'           => '0',
				'custom_attributes' => [ 'min' => '0', 'step' => '0.01' ],
				'desc_tip'          => true,
			],
			'max_order_amount'      => [
				'title'             => __( 'Maximum Order Amount', 'wp-lunapay' ),
				'type'              => 'number',
				'description'       => __( 'Maximum order total (in store currency) to show MoonPay at checkout. Leave 0 for no maximum.', 'wp-lunapay' ),
				'default'           => '0',
				'custom_attributes' => [ 'min' => '0', 'step' => '0.01' ],
				'desc_tip'          => true,
			],
			'success_message'       => [
				'title'       => __( 'Custom Success Message', 'wp-lunapay' ),
				'type'        => 'textarea',
				'description' => __( 'Message shown on the thank-you page after MoonPay payment. Leave empty to use the WooCommerce default.', 'wp-lunapay' ),
				'default'     => '',
				'desc_tip'    => true,
			],
			'order_statuses_section' => [
				'title' => __( 'Order Status Mapping', 'wp-lunapay' ),
				'type'  => 'title',
			],
			'order_status_pending'  => [
				'title'       => __( 'Pending Payment Status', 'wp-lunapay' ),
				'type'        => 'select',
				'options'     => wc_get_order_statuses(),
				'default'     => 'wc-pending',
				'description' => __( 'Order status when payment is initiated.', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'order_status_complete' => [
				'title'       => __( 'Completed Payment Status', 'wp-lunapay' ),
				'type'        => 'select',
				'options'     => wc_get_order_statuses(),
				'default'     => 'wc-processing',
				'description' => __( 'Order status when payment is confirmed by MoonPay.', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'order_status_failed'   => [
				'title'       => __( 'Failed Payment Status', 'wp-lunapay' ),
				'type'        => 'select',
				'options'     => wc_get_order_statuses(),
				'default'     => 'wc-failed',
				'description' => __( 'Order status when MoonPay reports a failure.', 'wp-lunapay' ),
				'desc_tip'    => true,
			],
			'debug'                 => [
				'title'   => __( 'Debug Logging', 'wp-lunapay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable debug log (WooCommerce → Status → Logs)', 'wp-lunapay' ),
				'default' => 'no',
			],
			'webhook_secret_note'   => [
				'title'       => __( 'Webhook URL', 'wp-lunapay' ),
				'type'        => 'title',
				'description' => sprintf(
					/* translators: %s = webhook URL */
					__( 'Add this URL in your MoonPay dashboard as a webhook endpoint: <code>%s</code>', 'wp-lunapay' ),
					esc_url( WC()->api_request_url( 'wp_lunapay_webhook' ) )
				),
			],
			'wplunapay_credit'     => [
				'title'       => '',
				'type'        => 'title',
				'description' => sprintf(
					/* translators: %s = WPLunaPay link */
					__( 'Plugin developed by <a href="%s" target="_blank" rel="noopener">wprealwise.com</a> — Professional WordPress &amp; WooCommerce Development.', 'wp-lunapay' ),
					'https://wprealwise.com'
				),
			],
		];
	}

	// -------------------------------------------------------------------------
	// Availability — hide gateway when order is outside configured limits
	// -------------------------------------------------------------------------

	public function is_available(): bool {
		if ( ! parent::is_available() ) {
			return false;
		}

		// Check min/max only during checkout (WC_Cart may not exist elsewhere)
		if ( ! is_checkout() || ! WC()->cart ) {
			return true;
		}

		$total = (float) WC()->cart->get_total( 'raw' );

		$min = (float) $this->get_option( 'min_order_amount', '0' );
		if ( $min > 0 && $total < $min ) {
			return false;
		}

		$max = (float) $this->get_option( 'max_order_amount', '0' );
		if ( $max > 0 && $total > $max ) {
			return false;
		}

		return true;
	}

	// -------------------------------------------------------------------------
	// Checkout / payment processing
	// -------------------------------------------------------------------------

	public function process_payment( $order_id ): array {
		// Guard: refuse to process if API keys are not configured
		if ( empty( $this->get_option( 'publishable_key' ) ) || empty( $this->get_option( 'secret_key' ) ) ) {
			wc_add_notice(
				__( 'MoonPay is not yet configured. Please contact the store owner.', 'wp-lunapay' ),
				'error'
			);
			return [ 'result' => 'failure' ];
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wc_add_notice( __( 'Order not found.', 'wp-lunapay' ), 'error' );
			return [ 'result' => 'failure' ];
		}

		// Enforce minimum order amount
		$min = (float) $this->get_option( 'min_order_amount', '0' );
		if ( $min > 0 && (float) $order->get_total() < $min ) {
			wc_add_notice( sprintf(
				/* translators: %s = formatted minimum amount */
				__( 'The minimum order amount for MoonPay crypto payment is %s.', 'wp-lunapay' ),
				wc_price( $min )
			), 'error' );
			return [ 'result' => 'failure' ];
		}

		// Enforce maximum order amount
		$max = (float) $this->get_option( 'max_order_amount', '0' );
		if ( $max > 0 && (float) $order->get_total() > $max ) {
			wc_add_notice( sprintf(
				/* translators: %s = formatted maximum amount */
				__( 'The maximum order amount for MoonPay crypto payment is %s.', 'wp-lunapay' ),
				wc_price( $max )
			), 'error' );
			return [ 'result' => 'failure' ];
		}

		// NOTE: Do NOT call wc_reduce_stock_levels() here.
		// WooCommerce already reduces stock during checkout (via woocommerce_checkout_order_created)
		// before process_payment() is ever called. Calling it again would double-deduct inventory.
		// Stock is restored by the webhook handler on failed/cancelled status.

		// Set order status to pending
		$pending_status = str_replace( 'wc-', '', $this->get_option( 'order_status_pending', 'wc-pending' ) );
		$order->update_status( $pending_status, __( 'Awaiting MoonPay payment.', 'wp-lunapay' ) );

		$this->log( 'Processing payment for order #' . $order_id );

		return [
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		];
	}

	/**
	 * @param int|string $order_id Passed by WooCommerce as mixed; avoid strict int type hint.
	 */
	public function receipt_page( $order_id ): void {
		$order = wc_get_order( absint( $order_id ) );
		if ( ! $order ) {
			echo '<p>' . esc_html__( 'Order not found.', 'wp-lunapay' ) . '</p>';
			return;
		}
		echo $this->build_widget_output( $order ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Thank-you page callback — shows custom success message if configured.
	 */
	public function thankyou_page( int $order_id ): void {
		$message = $this->get_option( 'success_message', '' );
		if ( ! empty( $message ) ) {
			echo '<div class="woocommerce-notice woocommerce-notice--success wp-lunapay-success-msg">'
			     . wp_kses_post( wpautop( $message ) )
			     . '</div>';
		}
	}

	public function build_widget_output( WC_Order $order ): string {
		$widget_url   = $this->get_widget_url_for_order( $order );
		$widget_mode  = $this->get_option( 'widget_mode', 'redirect' );
		$iframe_height = max( 300, absint( $this->get_option( 'iframe_height', '620' ) ) );
		$order_id     = $order->get_id();

		ob_start();
		include WP_LUNAPAY_PLUGIN_DIR . 'templates/payment-widget.php';
		// ob_get_clean() returns false on failure; fall back to empty string
		return ob_get_clean() ?: '';
	}

	private function get_widget_url_for_order( WC_Order $order ): string {
		$currency    = get_woocommerce_currency();
		$amount      = (float) $order->get_total();
		$email       = $order->get_billing_email();
		$order_id    = $order->get_id();
		$order_key   = $order->get_order_key();
		$crypto_code = $this->get_option( 'default_crypto', 'eth' );
		$color       = ltrim( $this->get_option( 'color_code', '#7B3FE4' ), '#' );

		$redirect_url = $this->get_return_url( $order );
		$webhook_url  = WC()->api_request_url( 'wp_lunapay_webhook' );

		$params = [
			'currencyCode'          => $crypto_code,
			'baseCurrencyCode'      => strtolower( $currency ),
			'baseCurrencyAmount'    => $amount,
			'email'                 => $email,
			'externalTransactionId' => 'order_' . $order_id . '_' . $order_key,
			'redirectURL'           => $redirect_url,
			'webhookStatusUrl'      => $webhook_url,
			// Pass raw '#RRGGBB' — http_build_query will percent-encode '#' to '%23'.
			// DO NOT pre-encode: passing '%23...' causes double-encoding → '%2523...'
			'colorCode'             => '#' . $color,
		];

		// Restrict visible currencies in the widget (correct MoonPay param: enabledCurrencies)
		$allowed = $this->get_option( 'allowed_cryptos', '' );
		if ( ! empty( $allowed ) ) {
			// MoonPay accepts comma-separated codes e.g. "eth,btc,usdc"
			$params['enabledCurrencies'] = $allowed;
		}

		$url = $this->api->get_widget_url( $params );

		// Store widget URL on order for reference
		$order->update_meta_data( '_moonpay_widget_url', $url );
		$order->save_meta_data();

		return $url;
	}

	// -------------------------------------------------------------------------
	// Refunds
	// -------------------------------------------------------------------------

	public function process_refund( $order_id, $amount = null, $reason = '' ): bool|WP_Error {
		// MoonPay does not currently expose a refund API for merchants.
		// Guide the merchant to handle manually.
		return new WP_Error(
			'moonpay_no_refund_api',
			__( 'MoonPay does not support programmatic refunds. Please process the refund manually via your MoonPay merchant dashboard.', 'wp-lunapay' )
		);
	}

	// -------------------------------------------------------------------------
	// Assets
	// -------------------------------------------------------------------------

	public function enqueue_scripts(): void {
		if ( ! is_checkout() && ! is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}

		wp_enqueue_style(
			'wp-lunapay',
			WP_LUNAPAY_PLUGIN_URL . 'assets/css/moonpay-gateway.css',
			[],
			WP_LUNAPAY_VERSION
		);

		wp_enqueue_script(
			'wp-lunapay',
			WP_LUNAPAY_PLUGIN_URL . 'assets/js/moonpay-gateway.js',
			[ 'jquery' ],
			WP_LUNAPAY_VERSION,
			true
		);

		wp_localize_script( 'wp-lunapay', 'wpLunaPay', [
			'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'wp_lunapay_nonce' ),
			'widgetMode' => $this->get_option( 'widget_mode', 'redirect' ),
			'i18n'       => [
				'payNow'       => __( 'Pay Now', 'wp-lunapay' ),
				'processing'   => __( 'Processing…', 'wp-lunapay' ),
				'errorMessage' => __( 'Payment failed. Please try again.', 'wp-lunapay' ),
			],
		] );
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	public function get_api(): WP_LunaPay_API {
		return $this->api;
	}

	private function make_api(): WP_LunaPay_API {
		$sandbox = $this->get_option( 'sandbox' ) === 'yes';
		$pub_key = $this->get_option( 'publishable_key', '' );
		$sec_key = $this->get_option( 'secret_key', '' );
		return new WP_LunaPay_API( $pub_key, $sec_key, $sandbox );
	}

	public function is_sandbox(): bool {
		return $this->get_option( 'sandbox' ) === 'yes';
	}

	public function log( string $message, string $level = 'info' ): void {
		if ( $this->get_option( 'debug' ) !== 'yes' ) {
			return;
		}
		$logger  = wc_get_logger();
		$context = [ 'source' => 'wp-lunapay' ];
		$logger->log( $level, $message, $context );
	}

	/**
	 * Validate API keys after settings save — show admin notice if keys look wrong.
	 */
	public function validate_api_keys(): void {
		// Re-read freshly saved options
		$pub = get_option( 'woocommerce_moonpay_settings', [] )['publishable_key'] ?? '';
		$sec = get_option( 'woocommerce_moonpay_settings', [] )['secret_key'] ?? '';

		if ( empty( $pub ) || empty( $sec ) ) {
			WC_Admin_Settings::add_error(
				__( 'MoonPay: Publishable Key and Secret Key are required.', 'wp-lunapay' )
			);
			return;
		}

		// MoonPay publishable keys start with 'pk_' and secret keys with 'sk_'
		if ( ! str_starts_with( $pub, 'pk_' ) ) {
			WC_Admin_Settings::add_error(
				__( 'MoonPay: Publishable Key should start with "pk_". Please check your key.', 'wp-lunapay' )
			);
		}
		if ( ! str_starts_with( $sec, 'sk_' ) ) {
			WC_Admin_Settings::add_error(
				__( 'MoonPay: Secret Key should start with "sk_". Please check your key.', 'wp-lunapay' )
			);
		}
	}

	/**
	 * Enqueue styles/scripts on WooCommerce admin order screens.
	 */
	public function enqueue_admin_scripts( string $hook ): void {
		$admin_screens = [
			'woocommerce_page_wc-orders',      // HPOS order list
			'woocommerce_page_wc-settings',    // WC settings (for sandbox toggle)
			'post.php',                        // classic shop_order edit
			'post-new.php',
		];

		if ( ! in_array( $hook, $admin_screens, true ) ) {
			return;
		}

		wp_enqueue_style(
			'wp-lunapay-admin',
			WP_LUNAPAY_PLUGIN_URL . 'assets/css/moonpay-admin.css',
			[],
			WP_LUNAPAY_VERSION
		);

		// Only load JS on settings page (for go-live sandbox confirmation) or order screens
		if ( in_array( $hook, [ 'woocommerce_page_wc-settings', 'post.php', 'post-new.php', 'woocommerce_page_wc-orders' ], true ) ) {
			wp_enqueue_script(
				'wp-lunapay-admin',
				WP_LUNAPAY_PLUGIN_URL . 'assets/js/moonpay-admin.js',
				[ 'jquery' ],
				WP_LUNAPAY_VERSION,
				true
			);
			wp_localize_script( 'wp-lunapay-admin', 'wpLunaPayAdmin',
				WP_LunaPay_Setup_Wizard::js_data()
			);
		}
	}
}
