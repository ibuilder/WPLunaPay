﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * Shortcodes provided by the MoonPay Gateway plugin.
 *
 * [moonpay_buy]                     – Standalone MoonPay buy widget
 * [moonpay_order_status order_id=""] – Show payment status for an order
 * [moonpay_crypto_price currency="eth" fiat="usd"] – Live price display
 * [moonpay_button label="" url=""]  – Styled CTA button linking to MoonPay
 */
class WP_LunaPay_Shortcodes {

	public static function init(): void {
		add_shortcode( 'moonpay_buy', [ self::class, 'shortcode_buy_widget' ] );
		add_shortcode( 'moonpay_order_status', [ self::class, 'shortcode_order_status' ] );
		add_shortcode( 'moonpay_crypto_price', [ self::class, 'shortcode_crypto_price' ] );
		add_shortcode( 'moonpay_button', [ self::class, 'shortcode_button' ] );

		add_action( 'wp_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
		add_action( 'wp_ajax_wp_lunapay_get_price', [ self::class, 'ajax_get_price' ] );
		add_action( 'wp_ajax_nopriv_wp_lunapay_get_price', [ self::class, 'ajax_get_price' ] );
	}

	public static function enqueue_assets(): void {
		wp_register_style(
			'wp-lunapay-shortcodes',
			WP_LUNAPAY_PLUGIN_URL . 'assets/css/moonpay-shortcodes.css',
			[],
			WP_LUNAPAY_VERSION
		);
		wp_register_script(
			'wp-lunapay-shortcodes',
			WP_LUNAPAY_PLUGIN_URL . 'assets/js/moonpay-shortcodes.js',
			[ 'jquery' ],
			WP_LUNAPAY_VERSION,
			true
		);
		wp_localize_script( 'wp-lunapay-shortcodes', 'wpLunaPayShortcodes', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'wp_lunapay_sc_nonce' ),
		] );
	}

	// -------------------------------------------------------------------------
	// [moonpay_buy currency="eth" amount="100" fiat="usd" mode="iframe"]
	// -------------------------------------------------------------------------

	public static function shortcode_buy_widget( array $atts ): string {
		$atts = shortcode_atts( [
			'currency' => 'eth',
			'amount'   => '',
			'fiat'     => strtolower( get_woocommerce_currency() ),
			'mode'     => 'iframe',   // iframe | redirect | popup
			'height'   => '600',
			'width'    => '100%',
			'class'    => '',
		], $atts, 'moonpay_buy' );

		$gateway = self::get_gateway();
		if ( ! $gateway ) {
			return '<p class="moonpay-error">' . esc_html__( 'MoonPay gateway is not configured.', 'wp-lunapay' ) . '</p>';
		}

		$params = [
			'currencyCode'     => sanitize_text_field( $atts['currency'] ),
			'baseCurrencyCode' => sanitize_text_field( $atts['fiat'] ),
		];
		if ( ! empty( $atts['amount'] ) ) {
			$params['baseCurrencyAmount'] = (float) $atts['amount'];
		}

		$widget_url = $gateway->get_api()->get_widget_url( $params );
		$mode       = sanitize_key( $atts['mode'] );
		$height     = absint( $atts['height'] );
		$width      = sanitize_text_field( $atts['width'] );
		$extra_css  = sanitize_html_class( $atts['class'] );

		wp_enqueue_style( 'wp-lunapay-shortcodes' );
		wp_enqueue_script( 'wp-lunapay-shortcodes' );

		ob_start();
		if ( $mode === 'iframe' ) {
			?>
			<div class="moonpay-widget-wrap <?php echo esc_attr( $extra_css ); ?>">
				<iframe
					src="<?php echo esc_url( $widget_url ); ?>"
					width="<?php echo esc_attr( $width ); ?>"
					height="<?php echo esc_attr( $height ); ?>px"
					frameborder="0"
					allow="accelerometer; autoplay; camera; gyroscope; payment"
					title="<?php esc_attr_e( 'MoonPay Buy Widget', 'wp-lunapay' ); ?>"
					class="moonpay-iframe"
				></iframe>
			</div>
			<?php
		} elseif ( $mode === 'popup' ) {
			?>
			<div class="moonpay-popup-wrap <?php echo esc_attr( $extra_css ); ?>">
				<button
					class="moonpay-popup-trigger button"
					data-url="<?php echo esc_url( $widget_url ); ?>"
				>
					<?php esc_html_e( 'Buy Crypto with MoonPay', 'wp-lunapay' ); ?>
				</button>
				<div class="moonpay-popup-overlay" style="display:none;">
					<div class="moonpay-popup-modal">
						<button class="moonpay-popup-close">&times;</button>
						<iframe
							src=""
							data-src="<?php echo esc_url( $widget_url ); ?>"
							frameborder="0"
							allow="accelerometer; autoplay; camera; gyroscope; payment"
							title="<?php esc_attr_e( 'MoonPay Buy Widget', 'wp-lunapay' ); ?>"
						></iframe>
					</div>
				</div>
			</div>
			<?php
		} else {
			// redirect
			?>
			<div class="moonpay-redirect-wrap <?php echo esc_attr( $extra_css ); ?>">
				<a href="<?php echo esc_url( $widget_url ); ?>" target="_blank" rel="noopener noreferrer" class="moonpay-redirect-button button">
					<?php esc_html_e( 'Buy Crypto with MoonPay', 'wp-lunapay' ); ?>
				</a>
			</div>
			<?php
		}

		return ob_get_clean();
	}

	// -------------------------------------------------------------------------
	// [moonpay_order_status order_id="123"]
	// -------------------------------------------------------------------------

	public static function shortcode_order_status( array $atts ): string {
		$atts = shortcode_atts( [
			'order_id' => '',
			'class'    => '',
		], $atts, 'moonpay_order_status' );

		$order_id = absint( $atts['order_id'] );

		// If no order ID provided, try to get from query var (thank-you page)
		if ( ! $order_id ) {
			global $wp;
			$order_id = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
		}

		if ( ! $order_id ) {
			return '';
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || $order->get_payment_method() !== 'moonpay' ) {
			return '';
		}

		// Only show to order owner or admin
		if ( ! current_user_can( 'manage_woocommerce' ) && get_current_user_id() !== $order->get_customer_id() ) {
			return '';
		}

		$mp_status = $order->get_meta( '_moonpay_status' );
		$mp_tx_id  = $order->get_meta( '_moonpay_transaction_id' );
		$wc_status = wc_get_order_status_name( $order->get_status() );

		wp_enqueue_style( 'wp-lunapay-shortcodes' );

		ob_start();
		?>
		<div class="moonpay-order-status <?php echo esc_attr( $atts['class'] ); ?>" data-order-id="<?php echo esc_attr( $order_id ); ?>">
			<h3><?php esc_html_e( 'MoonPay Payment Status', 'wp-lunapay' ); ?></h3>
			<table class="moonpay-status-table">
				<tr>
					<th><?php esc_html_e( 'Order Status', 'wp-lunapay' ); ?></th>
					<td><?php echo esc_html( $wc_status ); ?></td>
				</tr>
				<?php if ( $mp_status ) : ?>
				<tr>
					<th><?php esc_html_e( 'MoonPay Status', 'wp-lunapay' ); ?></th>
					<td><span class="moonpay-status-badge moonpay-status-<?php echo esc_attr( $mp_status ); ?>"><?php echo esc_html( ucfirst( $mp_status ) ); ?></span></td>
				</tr>
				<?php endif; ?>
				<?php if ( $mp_tx_id ) : ?>
				<tr>
					<th><?php esc_html_e( 'Transaction ID', 'wp-lunapay' ); ?></th>
					<td><code><?php echo esc_html( $mp_tx_id ); ?></code></td>
				</tr>
				<?php endif; ?>
			</table>
		</div>
		<?php
		return ob_get_clean();
	}

	// -------------------------------------------------------------------------
	// [moonpay_crypto_price currency="eth" fiat="usd" show_change="true"]
	// -------------------------------------------------------------------------

	public static function shortcode_crypto_price( array $atts ): string {
		$atts = shortcode_atts( [
			'currency'    => 'eth',
			'fiat'        => 'usd',
			'show_change' => 'false',
			'class'       => '',
		], $atts, 'moonpay_crypto_price' );

		wp_enqueue_style( 'wp-lunapay-shortcodes' );
		wp_enqueue_script( 'wp-lunapay-shortcodes' );

		$currency = strtolower( sanitize_key( $atts['currency'] ) );
		$fiat     = strtolower( sanitize_key( $atts['fiat'] ) );

		ob_start();
		?>
		<span
			class="moonpay-price-ticker <?php echo esc_attr( $atts['class'] ); ?>"
			data-currency="<?php echo esc_attr( $currency ); ?>"
			data-fiat="<?php echo esc_attr( $fiat ); ?>"
			data-show-change="<?php echo esc_attr( $atts['show_change'] ); ?>"
		>
			<span class="moonpay-price-value">
				<span class="moonpay-price-spinner"><?php esc_html_e( 'Loading…', 'wp-lunapay' ); ?></span>
			</span>
			<?php if ( $atts['show_change'] === 'true' ) : ?>
				<span class="moonpay-price-change"></span>
			<?php endif; ?>
		</span>
		<?php
		return ob_get_clean();
	}

	// -------------------------------------------------------------------------
	// [moonpay_button label="Buy BTC" currency="btc" fiat="usd" amount="50"]
	// -------------------------------------------------------------------------

	public static function shortcode_button( array $atts ): string {
		$atts = shortcode_atts( [
			'label'    => __( 'Buy Crypto', 'wp-lunapay' ),
			'currency' => 'eth',
			'fiat'     => strtolower( get_woocommerce_currency() ),
			'amount'   => '',
			'target'   => '_blank',
			'class'    => '',
		], $atts, 'moonpay_button' );

		$gateway = self::get_gateway();
		if ( ! $gateway ) {
			return '';
		}

		$params = [
			'currencyCode'     => sanitize_text_field( $atts['currency'] ),
			'baseCurrencyCode' => sanitize_text_field( $atts['fiat'] ),
		];
		if ( ! empty( $atts['amount'] ) ) {
			$params['baseCurrencyAmount'] = (float) $atts['amount'];
		}

		$url = $gateway->get_api()->get_widget_url( $params );

		wp_enqueue_style( 'wp-lunapay-shortcodes' );

		return sprintf(
			'<a href="%s" class="moonpay-cta-button %s" target="%s" rel="noopener noreferrer">%s</a>',
			esc_url( $url ),
			esc_attr( $atts['class'] ),
			esc_attr( $atts['target'] ),
			esc_html( $atts['label'] )
		);
	}

	// -------------------------------------------------------------------------
	// AJAX price fetch
	// -------------------------------------------------------------------------

	public static function ajax_get_price(): void {
		check_ajax_referer( 'wp_lunapay_sc_nonce', 'nonce' );

		$currency = sanitize_key( $_POST['currency'] ?? 'eth' );
		$fiat     = sanitize_key( $_POST['fiat'] ?? 'usd' );

		// Validate inputs to prevent arbitrary API calls
		if ( strlen( $currency ) > 30 || strlen( $fiat ) > 10 ) {
			wp_send_json_error( 'Invalid parameters' );
		}

		// Cache price for 60 seconds to avoid API rate-limit abuse.
		// Key is per currency-pair; shared across all visitors.
		$cache_key    = 'wp_lunapay_price_' . $currency . '_' . $fiat;
		$cached_price = get_transient( $cache_key );

		if ( $cached_price !== false ) {
			wp_send_json_success( [
				'price'    => $cached_price,
				'currency' => strtoupper( $currency ),
				'fiat'     => strtoupper( $fiat ),
				'cached'   => true,
			] );
		}

		$gateway = self::get_gateway();
		if ( ! $gateway ) {
			wp_send_json_error( 'Gateway not available' );
		}

		$result = $gateway->get_api()->get_buy_quote( $currency, $fiat, 1 );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		$price = $result['quoteCurrencyPrice'] ?? null;

		// Cache for 60 seconds
		if ( null !== $price ) {
			set_transient( $cache_key, $price, 60 );
		}

		wp_send_json_success( [
			'price'    => $price,
			'currency' => strtoupper( $currency ),
			'fiat'     => strtoupper( $fiat ),
			'cached'   => false,
		] );
	}

	// -------------------------------------------------------------------------

	private static function get_gateway(): ?WP_LunaPay_Gateway {
		$gateways = WC()->payment_gateways()->payment_gateways();
		return $gateways['moonpay'] ?? null;
	}
}
