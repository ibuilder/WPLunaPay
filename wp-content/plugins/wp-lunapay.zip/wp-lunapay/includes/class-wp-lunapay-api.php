﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * MoonPay REST API client.
 *
 * Handles signature generation and all HTTP calls to the MoonPay v3 API.
 */
class WP_LunaPay_API {

	private string $publishable_key;
	private string $secret_key;
	private bool   $sandbox;

	const API_BASE_LIVE    = 'https://api.moonpay.com/v3/';
	const API_BASE_SANDBOX = 'https://api.moonpay.com/v3/'; // MoonPay uses same endpoint; sandbox keys differ
	const WIDGET_LIVE      = 'https://buy.moonpay.com';
	const WIDGET_SANDBOX   = 'https://buy-sandbox.moonpay.com';

	public function __construct( string $publishable_key, string $secret_key, bool $sandbox = false ) {
		$this->publishable_key = $publishable_key;
		$this->secret_key      = $secret_key;
		$this->sandbox         = $sandbox;
	}

	// -------------------------------------------------------------------------
	// Widget URL helpers
	// -------------------------------------------------------------------------

	/**
	 * Build a signed MoonPay widget URL for an order.
	 *
	 * @param array{
	 *   currency_code: string,
	 *   base_currency_code: string,
	 *   base_currency_amount: float,
	 *   email: string,
	 *   external_transaction_id: string,
	 *   redirect_url: string,
	 *   webhook_status_url: string,
	 * } $params
	 */
	public function get_widget_url( array $params ): string {
		$base = $this->sandbox ? self::WIDGET_SANDBOX : self::WIDGET_LIVE;

		// Build query from merged params. Do NOT pre-encode values like colorCode —
		// http_build_query handles encoding. Passing '%23' would produce '%2523' (double-encode bug).
		$merged = array_merge( [ 'apiKey' => $this->publishable_key ], $params );
		$query  = http_build_query( $merged, '', '&', PHP_QUERY_RFC3986 );

		// MoonPay signature is computed over the raw query string including the leading '?'
		$signature  = $this->sign( '?' . $query );
		$signed_url = $base . '?' . $query . '&signature=' . rawurlencode( $signature );

		return $signed_url;
	}

	/**
	 * Sign a query string with the secret key using HMAC-SHA256 → base64.
	 */
	public function sign( string $query_string ): string {
		return base64_encode( hash_hmac( 'sha256', $query_string, $this->secret_key, true ) );
	}

	/**
	 * Validate an incoming MoonPay webhook signature.
	 */
	public function verify_webhook_signature( string $payload, string $received_signature ): bool {
		$expected = base64_encode( hash_hmac( 'sha256', $payload, $this->secret_key, true ) );
		return hash_equals( $expected, $received_signature );
	}

	// -------------------------------------------------------------------------
	// REST API calls
	// -------------------------------------------------------------------------

	/**
	 * Fetch a transaction by its MoonPay ID.
	 */
	public function get_transaction( string $transaction_id ): array|WP_Error {
		return $this->request( 'GET', 'transactions/' . urlencode( $transaction_id ) );
	}

	/**
	 * List transactions for an external ID (our order ID).
	 */
	public function get_transactions_by_external_id( string $external_id ): array|WP_Error {
		return $this->request( 'GET', 'transactions', [ 'externalTransactionId' => $external_id ] );
	}

	/**
	 * Fetch supported currencies list.
	 */
	public function get_currencies(): array|WP_Error {
		return $this->request( 'GET', 'currencies' );
	}

	/**
	 * Fetch a buy quote.
	 */
	public function get_buy_quote( string $crypto_code, string $fiat_code, float $fiat_amount ): array|WP_Error {
		return $this->request( 'GET', 'currencies/' . urlencode( $crypto_code ) . '/buy_quote', [
			'baseCurrencyAmount' => $fiat_amount,
			'baseCurrencyCode'   => $fiat_code,
		] );
	}

	// -------------------------------------------------------------------------
	// HTTP layer
	// -------------------------------------------------------------------------

	private function request( string $method, string $endpoint, array $params = [] ): array|WP_Error {
		// Use the correct base URL for sandbox vs live (same endpoint for MoonPay; keys differ)
		$base_url = $this->sandbox ? self::API_BASE_SANDBOX : self::API_BASE_LIVE;
		$url      = $base_url . ltrim( $endpoint, '/' );

		$args = [
			'method'  => $method,
			'timeout' => 30,
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Api-Key ' . $this->secret_key,
			],
		];

		if ( $method === 'GET' && ! empty( $params ) ) {
			$url = add_query_arg( $params, $url );
		} elseif ( ! empty( $params ) ) {
			$args['body'] = wp_json_encode( $params );
		}

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$code = wp_remote_retrieve_response_code( $response );

		if ( $code >= 400 ) {
			$message = $body['message'] ?? 'MoonPay API error';
			return new WP_Error( 'moonpay_api_error', $message, [ 'status' => $code, 'body' => $body ] );
		}

		return $body ?? [];
	}
}
