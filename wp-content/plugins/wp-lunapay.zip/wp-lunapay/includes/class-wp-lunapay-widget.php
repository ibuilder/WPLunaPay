﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * WordPress sidebar widget — MoonPay Buy/Price widget.
 *
 * Usage: Appearance → Widgets → "MoonPay Crypto Widget"
 * Also available as a Gutenberg block via the legacy widget block.
 */
class WP_LunaPay_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'wp_lunapay_widget',
			__( 'MoonPay Crypto Widget', 'wp-lunapay' ),
			[
				'description'                 => __( 'Show a MoonPay buy button or crypto price ticker in your sidebar.', 'wp-lunapay' ),
				'customize_selective_refresh' => true,
			]
		);
	}

	// -------------------------------------------------------------------------
	// Front-end output
	// -------------------------------------------------------------------------

	public function widget( $args, $instance ): void {
		$title   = apply_filters( 'widget_title', $instance['title'] ?? '', $instance, $this->id_base );
		$type    = $instance['type'] ?? 'button';
		$crypto  = sanitize_key( $instance['crypto'] ?? 'eth' );
		$fiat    = sanitize_key( $instance['fiat'] ?? strtolower( get_woocommerce_currency() ) );
		$amount  = (float) ( $instance['amount'] ?? 0 );
		$label   = sanitize_text_field( $instance['label'] ?? __( 'Buy Crypto', 'wp-lunapay' ) );
		$height  = absint( $instance['height'] ?? 500 );

		echo $args['before_widget']; // phpcs:ignore

		if ( $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore
		}

		$gateway = $this->get_gateway();

		if ( $type === 'price' ) {
			printf(
				'<div class="moonpay-widget-price">
					<span class="moonpay-price-ticker"
						data-currency="%s"
						data-fiat="%s"
						data-show-change="true">
						<span class="moonpay-price-value"><span class="moonpay-price-spinner">%s</span></span>
						<span class="moonpay-price-change"></span>
					</span>
					<p class="moonpay-price-label">%s / %s</p>
				</div>',
				esc_attr( $crypto ),
				esc_attr( $fiat ),
				esc_html__( 'Loading…', 'wp-lunapay' ),
				esc_html( strtoupper( $crypto ) ),
				esc_html( strtoupper( $fiat ) )
			);

			wp_enqueue_style( 'wp-lunapay-shortcodes' );
			wp_enqueue_script( 'wp-lunapay-shortcodes' );

		} elseif ( $type === 'iframe' && $gateway ) {
			$params = [
				'currencyCode'     => $crypto,
				'baseCurrencyCode' => $fiat,
			];
			if ( $amount > 0 ) {
				$params['baseCurrencyAmount'] = $amount;
			}
			$url = $gateway->get_api()->get_widget_url( $params );
			printf(
				'<div class="moonpay-widget-iframe-wrap">
					<iframe src="%s" width="100%%" height="%dpx"
						frameborder="0"
						allow="accelerometer; autoplay; camera; gyroscope; payment"
						title="%s"
						class="moonpay-iframe"></iframe>
				</div>',
				esc_url( $url ),
				$height,
				esc_attr__( 'MoonPay Buy Widget', 'wp-lunapay' )
			);

			wp_enqueue_style( 'wp-lunapay-shortcodes' );

		} else {
			// Default: buy button
			if ( $gateway ) {
				$params = [
					'currencyCode'     => $crypto,
					'baseCurrencyCode' => $fiat,
				];
				if ( $amount > 0 ) {
					$params['baseCurrencyAmount'] = $amount;
				}
				$url = $gateway->get_api()->get_widget_url( $params );
			} else {
				$url = 'https://www.moonpay.com';
			}

			printf(
				'<div class="moonpay-widget-button-wrap">
					<a href="%s" class="moonpay-cta-button" target="_blank" rel="noopener noreferrer">%s</a>
					<p class="moonpay-widget-tagline">%s</p>
				</div>',
				esc_url( $url ),
				esc_html( $label ),
				esc_html__( 'Powered by MoonPay', 'wp-lunapay' )
			);

			wp_enqueue_style( 'wp-lunapay-shortcodes' );
		}

		echo $args['after_widget']; // phpcs:ignore
	}

	// -------------------------------------------------------------------------
	// Admin form
	// -------------------------------------------------------------------------

	public function form( $instance ): void {
		$title  = $instance['title'] ?? __( 'Buy Crypto', 'wp-lunapay' );
		$type   = $instance['type'] ?? 'button';
		$crypto = $instance['crypto'] ?? 'eth';
		$fiat   = $instance['fiat'] ?? 'usd';
		$amount = $instance['amount'] ?? '';
		$label  = $instance['label'] ?? __( 'Buy Crypto', 'wp-lunapay' );
		$height = $instance['height'] ?? '500';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'wp-lunapay' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
				type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'type' ) ); ?>"><?php esc_html_e( 'Widget Type', 'wp-lunapay' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'type' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'type' ) ); ?>">
				<option value="button" <?php selected( $type, 'button' ); ?>><?php esc_html_e( 'Buy Button', 'wp-lunapay' ); ?></option>
				<option value="price" <?php selected( $type, 'price' ); ?>><?php esc_html_e( 'Price Ticker', 'wp-lunapay' ); ?></option>
				<option value="iframe" <?php selected( $type, 'iframe' ); ?>><?php esc_html_e( 'Embedded Widget (iFrame)', 'wp-lunapay' ); ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'crypto' ) ); ?>"><?php esc_html_e( 'Cryptocurrency', 'wp-lunapay' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'crypto' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'crypto' ) ); ?>"
				type="text" value="<?php echo esc_attr( $crypto ); ?>" placeholder="eth">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'fiat' ) ); ?>"><?php esc_html_e( 'Fiat Currency', 'wp-lunapay' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fiat' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'fiat' ) ); ?>"
				type="text" value="<?php echo esc_attr( $fiat ); ?>" placeholder="usd">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'amount' ) ); ?>"><?php esc_html_e( 'Default Amount (fiat)', 'wp-lunapay' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'amount' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'amount' ) ); ?>"
				type="number" step="0.01" min="0" value="<?php echo esc_attr( $amount ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'label' ) ); ?>"><?php esc_html_e( 'Button Label', 'wp-lunapay' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'label' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'label' ) ); ?>"
				type="text" value="<?php echo esc_attr( $label ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'height' ) ); ?>"><?php esc_html_e( 'iFrame Height (px)', 'wp-lunapay' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'height' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'height' ) ); ?>"
				type="number" min="200" value="<?php echo esc_attr( $height ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ): array {
		return [
			'title'  => sanitize_text_field( $new_instance['title'] ),
			'type'   => sanitize_key( $new_instance['type'] ),
			'crypto' => sanitize_key( $new_instance['crypto'] ),
			'fiat'   => sanitize_key( $new_instance['fiat'] ),
			'amount' => (float) $new_instance['amount'],
			'label'  => sanitize_text_field( $new_instance['label'] ),
			'height' => absint( $new_instance['height'] ),
		];
	}

	private function get_gateway(): ?WP_LunaPay_Gateway {
		$gateways = WC()->payment_gateways()->payment_gateways();
		return $gateways['moonpay'] ?? null;
	}
}
