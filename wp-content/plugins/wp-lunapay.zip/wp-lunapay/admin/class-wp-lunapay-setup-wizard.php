﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * Six-step guided Setup Wizard.
 *
 * Accessible at: WooCommerce → MoonPay → Setup Wizard
 * or directly:   /wp-admin/admin.php?page=wp-lunapay-setup
 *
 * Steps
 *   1  Welcome / Get API keys
 *   2  Enter & Test API keys
 *   3  Register webhook
 *   4  Configure widget
 *   5  Create test order (sandbox)
 *   6  Go live
 */
class WP_LunaPay_Setup_Wizard {

	// Step slugs are handled inline via switch — no separate map needed.

	public static function init(): void {
		add_action( 'admin_menu', [ self::class, 'register_page' ] );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue' ] );

		// AJAX handlers
		add_action( 'wp_ajax_wp_lunapay_test_connection',  [ self::class, 'ajax_test_connection' ] );
		add_action( 'wp_ajax_wp_lunapay_test_webhook_url', [ self::class, 'ajax_test_webhook_url' ] );
		add_action( 'wp_ajax_wp_lunapay_create_test_order',[ self::class, 'ajax_create_test_order' ] );
		add_action( 'wp_ajax_wp_lunapay_go_live',          [ self::class, 'ajax_go_live' ] );
		add_action( 'wp_ajax_wp_lunapay_save_wizard_step', [ self::class, 'ajax_save_wizard_step' ] );
	}

	public static function register_page(): void {
		add_submenu_page(
			'woocommerce',
			__( 'MoonPay Setup Wizard', 'wp-lunapay' ),
			__( 'MoonPay Setup', 'wp-lunapay' ),
			'manage_woocommerce',
			'wp-lunapay-setup',
			[ self::class, 'render' ]
		);
	}

	public static function enqueue( string $hook ): void {
		if ( $hook !== 'woocommerce_page_wp-lunapay-setup' ) {
			return;
		}
		wp_enqueue_style(  'wp-lunapay-admin', WP_LUNAPAY_PLUGIN_URL . 'assets/css/moonpay-admin.css', [], WP_LUNAPAY_VERSION );
		wp_enqueue_script( 'wp-lunapay-admin', WP_LUNAPAY_PLUGIN_URL . 'assets/js/moonpay-admin.js', [ 'jquery' ], WP_LUNAPAY_VERSION, true );
		wp_localize_script( 'wp-lunapay-admin', 'wpLunaPayAdmin', self::js_data() );
	}

	public static function js_data(): array {
		return [
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'wp_lunapay_admin' ),
			'webhookUrl'  => WC()->api_request_url( 'wp_lunapay_webhook' ),
			'settingsUrl' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=moonpay' ),
			'wizardUrl'   => admin_url( 'admin.php?page=wp-lunapay-setup' ),
			'i18n'        => [
				// Status / feedback
				'testing'              => __( 'Testing…', 'wp-lunapay' ),
				'saving'               => __( 'Saving…', 'wp-lunapay' ),
				'connected'            => __( 'Connected!', 'wp-lunapay' ),
				'failed'               => __( 'Failed', 'wp-lunapay' ),
				'copied'               => __( 'Copied!', 'wp-lunapay' ),
				'copy'                 => __( 'Copy', 'wp-lunapay' ),
				'creating'             => __( 'Creating…', 'wp-lunapay' ),
				'goingLive'            => __( 'Switching to live mode…', 'wp-lunapay' ),
				'confirmGoLive'        => __( 'You are about to switch to LIVE mode. Real money will be processed. Are you sure?', 'wp-lunapay' ),
				'reachable'            => __( 'Webhook URL is reachable!', 'wp-lunapay' ),
				'notReachable'         => __( 'Could not reach webhook URL. Check your server and permalink settings.', 'wp-lunapay' ),
				// Button labels (for reset after async operations)
				'btnTestConnection'    => __( 'Test Connection', 'wp-lunapay' ),
				'btnSaveKeys'          => __( 'Save Keys', 'wp-lunapay' ),
				'btnTestReachability'  => __( 'Test Reachability', 'wp-lunapay' ),
				'btnSaveConfig'        => __( 'Save Configuration', 'wp-lunapay' ),
				'btnCreateTestOrder'   => __( 'Create Test Order', 'wp-lunapay' ),
				'btnAnotherTestOrder'  => __( 'Create Another Test Order', 'wp-lunapay' ),
				'btnGoLive'            => __( 'Switch to Live Mode', 'wp-lunapay' ),
				// Validation messages
				'enterBothKeys'        => __( 'Enter both Publishable Key and Secret Key first.', 'wp-lunapay' ),
				// Test order result template (uses %id%, %payUrl%, %orderUrl% as placeholders)
				'testOrderCreated'     => __( 'Test order #%id% created.', 'wp-lunapay' ),
				'openCheckout'         => __( 'Open Checkout →', 'wp-lunapay' ),
				'viewInAdmin'          => __( 'View in Admin', 'wp-lunapay' ),
			],
		];
	}

	// -------------------------------------------------------------------------
	// Render
	// -------------------------------------------------------------------------

	public static function render(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'wp-lunapay' ) );
		}

		$current_step = max( 1, min( 6, absint( $_GET['step'] ?? self::get_current_step() ) ) ); // phpcs:ignore

		$gateway     = self::get_gateway();
		$setup_data  = self::get_setup_data();
		$webhook_url = WC()->api_request_url( 'wp_lunapay_webhook' );
		?>
		<div class="wrap moonpay-wizard-wrap" id="moonpay-wizard">
			<div class="moonpay-wizard-header">
				<img src="<?php echo esc_url( WP_LUNAPAY_PLUGIN_URL . 'assets/images/moonpay-logo.svg' ); ?>" alt="MoonPay" class="moonpay-wizard-logo">
				<h1><?php esc_html_e( 'MoonPay Setup Wizard', 'wp-lunapay' ); ?></h1>
				<p class="moonpay-wizard-subtitle">
					<?php esc_html_e( 'Follow these steps to start accepting cryptocurrency payments on your store.', 'wp-lunapay' ); ?>
				</p>
			</div>

			<?php // Progress bar ?>
			<div class="moonpay-wizard-progress">
				<?php
				$step_labels = [
					1 => __( 'Get Keys', 'wp-lunapay' ),
					2 => __( 'Enter Keys', 'wp-lunapay' ),
					3 => __( 'Webhook', 'wp-lunapay' ),
					4 => __( 'Configure', 'wp-lunapay' ),
					5 => __( 'Test', 'wp-lunapay' ),
					6 => __( 'Go Live', 'wp-lunapay' ),
				];
				foreach ( $step_labels as $n => $label ) :
					$cls = 'moonpay-wizard-step';
					if ( $n < $current_step )  $cls .= ' completed';
					if ( $n === $current_step ) $cls .= ' active';
					$step_url = add_query_arg( 'step', $n, admin_url( 'admin.php?page=wp-lunapay-setup' ) );
				?>
				<a href="<?php echo esc_url( $step_url ); ?>" class="<?php echo esc_attr( $cls ); ?>">
					<span class="moonpay-wizard-step-num"><?php echo $n < $current_step ? '✓' : esc_html( $n ); ?></span>
					<span class="moonpay-wizard-step-label"><?php echo esc_html( $label ); ?></span>
				</a>
				<?php if ( $n < 6 ) : ?><span class="moonpay-wizard-connector"></span><?php endif; ?>
				<?php endforeach; ?>
			</div>

			<div class="moonpay-wizard-body">
				<?php
				switch ( $current_step ) {
					case 1: self::render_step_1(); break;
					case 2: self::render_step_2( $gateway ); break;
					case 3: self::render_step_3( $webhook_url, $setup_data ); break;
					case 4: self::render_step_4( $gateway ); break;
					case 5: self::render_step_5( $setup_data ); break;
					case 6: self::render_step_6( $gateway, $setup_data ); break;
				}
				?>
			</div>

			<div class="moonpay-wizard-footer">
				<?php if ( $current_step > 1 ) :
					$prev_url = add_query_arg( 'step', $current_step - 1, admin_url( 'admin.php?page=wp-lunapay-setup' ) );
				?>
				<a href="<?php echo esc_url( $prev_url ); ?>" class="button">&larr; <?php esc_html_e( 'Back', 'wp-lunapay' ); ?></a>
				<?php endif; ?>

				<?php if ( $current_step < 6 ) :
					$next_url = add_query_arg( 'step', $current_step + 1, admin_url( 'admin.php?page=wp-lunapay-setup' ) );
				?>
				<a href="<?php echo esc_url( $next_url ); ?>" class="button button-primary moonpay-wizard-next" id="moonpay-wizard-next">
					<?php esc_html_e( 'Next Step', 'wp-lunapay' ); ?> &rarr;
				</a>
				<?php else : ?>
				<button type="button" id="moonpay-go-live-btn" class="button button-primary moonpay-go-live-btn" style="display:none;">
					<?php esc_html_e( 'Switch to Live Mode', 'wp-lunapay' ); ?>
				</button>
				<?php endif; ?>

				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-lunapay-transactions' ) ); ?>" class="button moonpay-wizard-skip">
					<?php esc_html_e( 'Skip Wizard', 'wp-lunapay' ); ?>
				</a>
			</div>

			<div class="moonpay-admin-credit">
				<?php printf(
					/* translators: %s = WPLunaPay link */
					esc_html__( 'MoonPay Crypto Payments — developed by %s', 'wp-lunapay' ),
					'<a href="https://wprealwise.com" target="_blank" rel="noopener">wprealwise.com</a>'
				); ?>
			</div>
		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Step renderers
	// -------------------------------------------------------------------------

	private static function render_step_1(): void {
		?>
		<div class="moonpay-wizard-step-content">
			<h2><?php esc_html_e( 'Step 1: Get Your MoonPay API Keys', 'wp-lunapay' ); ?></h2>
			<p><?php esc_html_e( 'You need a MoonPay merchant account and API keys before proceeding.', 'wp-lunapay' ); ?></p>

			<div class="moonpay-wizard-instructions">
				<ol>
					<li>
						<?php printf(
							/* translators: %s = link */
							__( 'Go to <a href="%s" target="_blank" rel="noopener">dashboard.moonpay.com</a> and sign in or create a merchant account.', 'wp-lunapay' ),
							'https://dashboard.moonpay.com'
						); ?>
					</li>
					<li><?php esc_html_e( 'In the sidebar, click Developers → API Keys.', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'You will see two keys: a Publishable Key (starts with pk_) and a Secret Key (starts with sk_).', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'Keep both keys handy — you will enter them in the next step.', 'wp-lunapay' ); ?></li>
				</ol>
			</div>

			<div class="moonpay-wizard-callout moonpay-wizard-callout--info">
				<strong><?php esc_html_e( 'Sandbox vs Live', 'wp-lunapay' ); ?></strong><br>
				<?php esc_html_e( 'MoonPay provides separate Sandbox keys (pk_test_ / sk_test_) for testing and Live keys (pk_live_ / sk_live_) for production. Start with Sandbox keys — you can switch to Live in the final step.', 'wp-lunapay' ); ?>
			</div>

			<a href="https://dashboard.moonpay.com/api_keys" target="_blank" rel="noopener" class="button button-primary moonpay-wizard-external-btn">
				<?php esc_html_e( 'Open MoonPay Dashboard →', 'wp-lunapay' ); ?>
			</a>
		</div>
		<?php
	}

	private static function render_step_2( ?WP_LunaPay_Gateway $gateway ): void {
		$pub_key = $gateway ? $gateway->get_option( 'publishable_key', '' ) : '';
		$sec_key = $gateway ? $gateway->get_option( 'secret_key', '' ) : '';
		$sandbox = $gateway ? $gateway->is_sandbox() : true;
		?>
		<div class="moonpay-wizard-step-content">
			<h2><?php esc_html_e( 'Step 2: Enter & Test Your API Keys', 'wp-lunapay' ); ?></h2>
			<p><?php esc_html_e( 'Enter your MoonPay API keys and verify they connect successfully.', 'wp-lunapay' ); ?></p>

			<table class="form-table moonpay-wizard-form">
				<tr>
					<th><label for="mp_sandbox"><?php esc_html_e( 'Mode', 'wp-lunapay' ); ?></label></th>
					<td>
						<label>
							<input type="checkbox" id="mp_sandbox" name="mp_sandbox" value="yes" <?php checked( $sandbox ); ?>>
							<?php esc_html_e( 'Sandbox (test) mode — use pk_test_ / sk_test_ keys', 'wp-lunapay' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th><label for="mp_pub_key"><?php esc_html_e( 'Publishable Key', 'wp-lunapay' ); ?></label></th>
					<td>
						<input type="text" id="mp_pub_key" name="mp_pub_key" class="regular-text"
							value="<?php echo esc_attr( $pub_key ); ?>"
							placeholder="pk_test_xxxxxxxxxxxxxxxxxxxx">
						<p class="description"><?php esc_html_e( 'Starts with pk_test_ (sandbox) or pk_live_ (live).', 'wp-lunapay' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="mp_sec_key"><?php esc_html_e( 'Secret Key', 'wp-lunapay' ); ?></label></th>
					<td>
						<input type="password" id="mp_sec_key" name="mp_sec_key" class="regular-text"
							value="<?php echo esc_attr( $sec_key ); ?>"
							placeholder="sk_test_xxxxxxxxxxxxxxxxxxxx">
						<p class="description"><?php esc_html_e( 'Starts with sk_test_ (sandbox) or sk_live_ (live). Never share this.', 'wp-lunapay' ); ?></p>
					</td>
				</tr>
			</table>

			<div class="moonpay-wizard-actions">
				<button type="button" id="moonpay-test-connection" class="button button-secondary">
					<?php esc_html_e( 'Test Connection', 'wp-lunapay' ); ?>
				</button>
				<button type="button" id="moonpay-save-keys" class="button button-primary">
					<?php esc_html_e( 'Save Keys', 'wp-lunapay' ); ?>
				</button>
				<span id="moonpay-test-result" class="moonpay-wizard-inline-result"></span>
			</div>

			<?php if ( $pub_key && $sec_key ) : ?>
			<div class="moonpay-wizard-callout moonpay-wizard-callout--success">
				<?php esc_html_e( 'API keys are saved. Click "Test Connection" to verify they are valid.', 'wp-lunapay' ); ?>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_step_3( string $webhook_url, array $setup_data ): void {
		$last_webhook = $setup_data['last_webhook_received'] ?? '';
		$webhook_tested = ! empty( $setup_data['webhook_reachable'] );
		?>
		<div class="moonpay-wizard-step-content">
			<h2><?php esc_html_e( 'Step 3: Register Your Webhook URL', 'wp-lunapay' ); ?></h2>
			<p>
				<?php esc_html_e( 'MoonPay sends payment status updates to your site via webhooks. You must register this URL in the MoonPay dashboard so your orders update automatically.', 'wp-lunapay' ); ?>
			</p>

			<div class="moonpay-webhook-url-box">
				<label><?php esc_html_e( 'Your Webhook URL', 'wp-lunapay' ); ?></label>
				<div class="moonpay-copy-row">
					<input type="text" id="moonpay-webhook-url-input" class="moonpay-webhook-url-text"
						value="<?php echo esc_attr( $webhook_url ); ?>" readonly>
					<button type="button" id="moonpay-copy-webhook" class="button" data-url="<?php echo esc_attr( $webhook_url ); ?>">
						<?php esc_html_e( 'Copy', 'wp-lunapay' ); ?>
					</button>
					<button type="button" id="moonpay-test-webhook-reachability" class="button button-secondary">
						<?php esc_html_e( 'Test Reachability', 'wp-lunapay' ); ?>
					</button>
					<span id="moonpay-webhook-reach-result" class="moonpay-wizard-inline-result"></span>
				</div>
			</div>

			<div class="moonpay-wizard-instructions">
				<strong><?php esc_html_e( 'How to register in MoonPay:', 'wp-lunapay' ); ?></strong>
				<ol>
					<li><?php printf( __( 'Go to <a href="%s" target="_blank" rel="noopener">MoonPay Dashboard → Developers → Webhooks</a>.', 'wp-lunapay' ), 'https://dashboard.moonpay.com/webhooks' ); ?></li>
					<li><?php esc_html_e( 'Click "Add Endpoint".', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'Paste the URL above into the "Endpoint URL" field.', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'Select all event types (or at minimum: transaction_updated, transaction_created).', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'Save. MoonPay will now send updates to your store.', 'wp-lunapay' ); ?></li>
				</ol>
			</div>

			<div class="moonpay-wizard-status-row">
				<div class="moonpay-wizard-status-item <?php echo $webhook_tested ? 'ok' : 'pending'; ?>">
					<span class="moonpay-wizard-status-icon"><?php echo $webhook_tested ? '✓' : '○'; ?></span>
					<?php esc_html_e( 'Webhook URL reachable', 'wp-lunapay' ); ?>
				</div>
				<div class="moonpay-wizard-status-item <?php echo $last_webhook ? 'ok' : 'pending'; ?>">
					<span class="moonpay-wizard-status-icon"><?php echo $last_webhook ? '✓' : '○'; ?></span>
					<?php if ( $last_webhook ) :
						printf(
							/* translators: %s = time ago */
							esc_html__( 'Last webhook received: %s ago', 'wp-lunapay' ),
							esc_html( human_time_diff( strtotime( $last_webhook ) ) )
						);
					else :
						esc_html_e( 'No webhook received yet — register above and complete a test order', 'wp-lunapay' );
					endif; ?>
				</div>
			</div>

			<a href="https://dashboard.moonpay.com/webhooks" target="_blank" rel="noopener" class="button moonpay-wizard-external-btn">
				<?php esc_html_e( 'Open MoonPay Webhooks →', 'wp-lunapay' ); ?>
			</a>
		</div>
		<?php
	}

	private static function render_step_4( ?WP_LunaPay_Gateway $gateway ): void {
		$mode       = $gateway ? $gateway->get_option( 'widget_mode', 'redirect' ) : 'redirect';
		$crypto     = $gateway ? $gateway->get_option( 'default_crypto', 'eth' ) : 'eth';
		$allowed    = $gateway ? $gateway->get_option( 'allowed_cryptos', 'eth,btc,usdc' ) : 'eth,btc,usdc';
		$color      = $gateway ? $gateway->get_option( 'color_code', '#7B3FE4' ) : '#7B3FE4';
		$title      = $gateway ? $gateway->get_option( 'title', __( 'Pay with Cryptocurrency', 'wp-lunapay' ) ) : '';
		$desc       = $gateway ? $gateway->get_option( 'description', '' ) : '';
		?>
		<div class="moonpay-wizard-step-content">
			<h2><?php esc_html_e( 'Step 4: Configure the Payment Widget', 'wp-lunapay' ); ?></h2>
			<p><?php esc_html_e( 'Customise how MoonPay appears at checkout and which cryptocurrencies are offered.', 'wp-lunapay' ); ?></p>

			<table class="form-table moonpay-wizard-form">
				<tr>
					<th><label for="mp_title"><?php esc_html_e( 'Checkout Title', 'wp-lunapay' ); ?></label></th>
					<td>
						<input type="text" id="mp_title" name="mp_title" class="regular-text" value="<?php echo esc_attr( $title ); ?>">
						<p class="description"><?php esc_html_e( 'Shown to customers at checkout.', 'wp-lunapay' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="mp_description"><?php esc_html_e( 'Checkout Description', 'wp-lunapay' ); ?></label></th>
					<td>
						<textarea id="mp_description" name="mp_description" rows="2" class="regular-text"><?php echo esc_textarea( $desc ); ?></textarea>
					</td>
				</tr>
				<tr>
					<th><label for="mp_widget_mode"><?php esc_html_e( 'Widget Display Mode', 'wp-lunapay' ); ?></label></th>
					<td>
						<select id="mp_widget_mode" name="mp_widget_mode">
							<option value="redirect" <?php selected( $mode, 'redirect' ); ?>><?php esc_html_e( 'Redirect to MoonPay (recommended)', 'wp-lunapay' ); ?></option>
							<option value="iframe"   <?php selected( $mode, 'iframe' );   ?>><?php esc_html_e( 'Embedded iFrame', 'wp-lunapay' ); ?></option>
							<option value="popup"    <?php selected( $mode, 'popup' );    ?>><?php esc_html_e( 'Modal Popup', 'wp-lunapay' ); ?></option>
						</select>
						<p class="description">
							<strong><?php esc_html_e( 'Redirect:', 'wp-lunapay' ); ?></strong> <?php esc_html_e( 'Sends customer to MoonPay.com — simplest, no CSP issues.', 'wp-lunapay' ); ?><br>
							<strong><?php esc_html_e( 'iFrame:', 'wp-lunapay' ); ?></strong> <?php esc_html_e( 'Widget appears on your page.', 'wp-lunapay' ); ?><br>
							<strong><?php esc_html_e( 'Popup:', 'wp-lunapay' ); ?></strong> <?php esc_html_e( 'Opens in a modal overlay.', 'wp-lunapay' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th><label for="mp_default_crypto"><?php esc_html_e( 'Default Cryptocurrency', 'wp-lunapay' ); ?></label></th>
					<td>
						<input type="text" id="mp_default_crypto" name="mp_default_crypto" class="small-text" value="<?php echo esc_attr( $crypto ); ?>" placeholder="eth">
						<p class="description"><?php esc_html_e( 'Pre-selected in the widget. E.g: eth, btc, usdc, usdc_polygon', 'wp-lunapay' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="mp_allowed_cryptos"><?php esc_html_e( 'Allowed Cryptocurrencies', 'wp-lunapay' ); ?></label></th>
					<td>
						<textarea id="mp_allowed_cryptos" name="mp_allowed_cryptos" rows="2" class="regular-text" placeholder="eth,btc,usdc,usdc_polygon"><?php echo esc_textarea( $allowed ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Comma-separated. Leave empty to allow all 100+ currencies MoonPay supports.', 'wp-lunapay' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="mp_color_code"><?php esc_html_e( 'Accent Color', 'wp-lunapay' ); ?></label></th>
					<td>
						<input type="color" id="mp_color_code" name="mp_color_code" value="<?php echo esc_attr( $color ); ?>">
						<p class="description"><?php esc_html_e( 'Brand color shown inside the MoonPay widget.', 'wp-lunapay' ); ?></p>
					</td>
				</tr>
			</table>

			<div class="moonpay-wizard-actions">
				<button type="button" id="moonpay-save-config" class="button button-primary">
					<?php esc_html_e( 'Save Configuration', 'wp-lunapay' ); ?>
				</button>
				<span id="moonpay-config-result" class="moonpay-wizard-inline-result"></span>
			</div>
		</div>
		<?php
	}

	private static function render_step_5( array $setup_data ): void {
		$test_order_id = $setup_data['test_order_id'] ?? 0;
		$gateway       = self::get_gateway();
		$is_sandbox     = $gateway ? $gateway->is_sandbox() : true;
		?>
		<div class="moonpay-wizard-step-content">
			<h2><?php esc_html_e( 'Step 5: Create & Complete a Test Order', 'wp-lunapay' ); ?></h2>

			<?php if ( ! $is_sandbox ) : ?>
			<div class="moonpay-wizard-callout moonpay-wizard-callout--warning">
				<strong><?php esc_html_e( 'Warning:', 'wp-lunapay' ); ?></strong>
				<?php esc_html_e( 'You are currently in LIVE mode. Switch to Sandbox mode in Step 2 before running a test order to avoid real charges.', 'wp-lunapay' ); ?>
			</div>
			<?php else : ?>
			<p><?php esc_html_e( 'This creates a real WooCommerce order in sandbox mode. Click "Open Checkout" to complete it with your sandbox MoonPay widget and verify the full payment flow.', 'wp-lunapay' ); ?></p>

			<div class="moonpay-wizard-test-order-box">
				<?php if ( $test_order_id ) : ?>
				<div class="moonpay-wizard-callout moonpay-wizard-callout--success" id="moonpay-test-order-result">
					<?php printf(
						/* translators: %s = order link */
						__( 'Test order <a href="%1$s" target="_blank">#%2$d</a> created. Complete the payment in MoonPay sandbox to verify webhooks update the order status.', 'wp-lunapay' ),
						esc_url( wc_get_order( $test_order_id )->get_edit_order_url() ),
						(int) $test_order_id
					); ?>
				</div>
				<?php else : ?>
				<p id="moonpay-test-order-result"></p>
				<?php endif; ?>

				<div class="moonpay-wizard-actions">
					<button type="button" id="moonpay-create-test-order" class="button button-primary">
						<?php echo $test_order_id
							? esc_html__( 'Create Another Test Order', 'wp-lunapay' )
							: esc_html__( 'Create Test Order', 'wp-lunapay' ); ?>
					</button>
					<?php if ( $test_order_id ) :
						$order = wc_get_order( $test_order_id );
						if ( $order ) : ?>
					<a href="<?php echo esc_url( $order->get_checkout_payment_url( true ) ); ?>"
						target="_blank" class="button">
						<?php esc_html_e( 'Open Checkout →', 'wp-lunapay' ); ?>
					</a>
					<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>"
						target="_blank" class="button">
						<?php esc_html_e( 'View Order in Admin', 'wp-lunapay' ); ?>
					</a>
					<?php endif; ?>
					<?php endif; ?>
				</div>
			</div>

			<div class="moonpay-wizard-instructions">
				<strong><?php esc_html_e( 'What to verify:', 'wp-lunapay' ); ?></strong>
				<ul>
					<li><?php esc_html_e( 'The MoonPay widget loads correctly at checkout.', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'After completing a sandbox payment, the order status in WooCommerce updates automatically (via webhook).', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'The MoonPay Payment Details metabox on the order shows the transaction ID and status.', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'You receive an order confirmation email (if WooCommerce email is configured).', 'wp-lunapay' ); ?></li>
				</ul>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_step_6( ?WP_LunaPay_Gateway $gateway, array $setup_data ): void {
		$is_sandbox      = $gateway ? $gateway->is_sandbox() : true;
		$has_keys        = $gateway && ! empty( $gateway->get_option( 'publishable_key' ) );
		$webhook_tested  = ! empty( $setup_data['webhook_reachable'] );
		$last_webhook    = $setup_data['last_webhook_received'] ?? '';
		$test_order_done = ! empty( $setup_data['test_order_id'] );

		$checklist = [
			'keys'    => [ 'done' => $has_keys,        'label' => __( 'API keys configured', 'wp-lunapay' ) ],
			'webhook' => [ 'done' => $webhook_tested,  'label' => __( 'Webhook URL reachable', 'wp-lunapay' ) ],
			'rx'      => [ 'done' => (bool)$last_webhook, 'label' => __( 'At least one webhook received', 'wp-lunapay' ) ],
			'test'    => [ 'done' => $test_order_done, 'label' => __( 'Test order created', 'wp-lunapay' ) ],
		];

		$all_clear = array_reduce( $checklist, fn( $carry, $item ) => $carry && $item['done'], true );
		?>
		<div class="moonpay-wizard-step-content">
			<h2><?php esc_html_e( 'Step 6: Go Live', 'wp-lunapay' ); ?></h2>
			<p>
				<?php esc_html_e( 'Review the checklist below. When everything is green, replace your Sandbox keys with Live keys and switch to Live mode.', 'wp-lunapay' ); ?>
			</p>

			<div class="moonpay-go-live-checklist">
				<?php foreach ( $checklist as $item ) : ?>
				<div class="moonpay-checklist-item <?php echo $item['done'] ? 'done' : 'not-done'; ?>">
					<span class="moonpay-checklist-icon"><?php echo $item['done'] ? '✓' : '✗'; ?></span>
					<span class="moonpay-checklist-label"><?php echo esc_html( $item['label'] ); ?></span>
				</div>
				<?php endforeach; ?>
			</div>

			<?php if ( ! $is_sandbox ) : ?>
			<div class="moonpay-wizard-callout moonpay-wizard-callout--success">
				<strong><?php esc_html_e( 'You are already in Live mode!', 'wp-lunapay' ); ?></strong>
				<?php esc_html_e( 'Your store is accepting real cryptocurrency payments via MoonPay.', 'wp-lunapay' ); ?>
			</div>
			<?php else : ?>
			<div class="moonpay-wizard-callout moonpay-wizard-callout--warning">
				<strong><?php esc_html_e( 'Before going live:', 'wp-lunapay' ); ?></strong>
				<ul style="margin:8px 0 0 20px;">
					<li><?php esc_html_e( 'Replace your Sandbox API keys (pk_test_ / sk_test_) with Live keys (pk_live_ / sk_live_) in Step 2.', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'Register the webhook URL in MoonPay Live mode (separate from Sandbox webhooks).', 'wp-lunapay' ); ?></li>
					<li><?php esc_html_e( 'Real money will be processed. Ensure your MoonPay account is fully verified.', 'wp-lunapay' ); ?></li>
				</ul>
			</div>

			<div class="moonpay-wizard-actions" style="margin-top:20px;">
				<?php if ( $all_clear ) : ?>
				<button type="button" id="moonpay-go-live-btn" class="button button-primary moonpay-go-live-btn">
					<?php esc_html_e( 'Switch to Live Mode Now', 'wp-lunapay' ); ?>
				</button>
				<?php else : ?>
				<div class="moonpay-wizard-callout moonpay-wizard-callout--info">
					<?php esc_html_e( 'Complete all checklist items above before switching to live mode.', 'wp-lunapay' ); ?>
				</div>
				<?php endif; ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=moonpay' ) ); ?>" class="button">
					<?php esc_html_e( 'Open Full Settings Page', 'wp-lunapay' ); ?>
				</a>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// AJAX handlers
	// -------------------------------------------------------------------------

	public static function ajax_test_connection(): void {
		check_ajax_referer( 'wp_lunapay_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Permission denied' );

		$pub = sanitize_text_field( $_POST['publishable_key'] ?? '' );
		$sec = sanitize_text_field( $_POST['secret_key'] ?? '' );
		$sbx = ( sanitize_key( $_POST['sandbox'] ?? 'yes' ) === 'yes' );

		if ( empty( $pub ) || empty( $sec ) ) {
			wp_send_json_error( __( 'Please enter both Publishable Key and Secret Key.', 'wp-lunapay' ) );
		}

		$api    = new WP_LunaPay_API( $pub, $sec, $sbx );
		$result = $api->get_currencies();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( sprintf(
				/* translators: %s = error message */
				__( 'Connection failed: %s', 'wp-lunapay' ),
				$result->get_error_message()
			) );
		}

		$count = is_array( $result ) ? count( $result ) : '?';
		wp_send_json_success( sprintf(
			/* translators: %d = number of currencies */
			__( 'Connected! %d currencies available.', 'wp-lunapay' ),
			$count
		) );
	}

	public static function ajax_save_wizard_step(): void {
		check_ajax_referer( 'wp_lunapay_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Permission denied' );

		$step = sanitize_key( $_POST['wizard_step'] ?? '' );
		$opts = get_option( 'woocommerce_moonpay_settings', [] );

		if ( $step === 'keys' ) {
			$pub = sanitize_text_field( $_POST['publishable_key'] ?? '' );
			$sec = sanitize_text_field( $_POST['secret_key'] ?? '' );
			$sbx = ( sanitize_key( $_POST['sandbox'] ?? 'yes' ) === 'yes' ) ? 'yes' : 'no';
			if ( ! empty( $pub ) ) $opts['publishable_key'] = $pub;
			if ( ! empty( $sec ) ) $opts['secret_key']      = $sec;
			$opts['sandbox'] = $sbx;
			update_option( 'woocommerce_moonpay_settings', $opts );
			wp_send_json_success( __( 'Keys saved.', 'wp-lunapay' ) );
		}

		if ( $step === 'config' ) {
			$map = [
				'widget_mode'    => 'sanitize_key',
				'default_crypto' => 'sanitize_key',
				'color_code'     => 'sanitize_hex_color',
				'title'          => 'sanitize_text_field',
				'description'    => 'sanitize_textarea_field',
			];
			foreach ( $map as $field => $fn ) {
				if ( isset( $_POST[ $field ] ) ) {
					$opts[ $field ] = $fn( $_POST[ $field ] );
				}
			}
			// Allowed cryptos — sanitize each code
			if ( isset( $_POST['allowed_cryptos'] ) ) {
				$codes = array_map( 'sanitize_key', explode( ',', $_POST['allowed_cryptos'] ) );
				$opts['allowed_cryptos'] = implode( ',', array_filter( $codes ) );
			}
			$opts['enabled'] = 'yes';
			update_option( 'woocommerce_moonpay_settings', $opts );
			wp_send_json_success( __( 'Configuration saved.', 'wp-lunapay' ) );
		}

		wp_send_json_error( 'Unknown step' );
	}

	public static function ajax_test_webhook_url(): void {
		check_ajax_referer( 'wp_lunapay_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Permission denied' );

		$webhook_url = WC()->api_request_url( 'wp_lunapay_webhook' );

		// HEAD request — we expect a non-5xx response (WC will return 200 or 401/400 since
		// we're not sending a valid payload, but any non-timeout/non-503 means the URL is routable)
		$response = wp_remote_head( $webhook_url, [ 'timeout' => 10, 'sslverify' => false ] );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( sprintf(
				__( 'URL not reachable: %s', 'wp-lunapay' ),
				$response->get_error_message()
			) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		// Any HTTP response (even 4xx) means the URL is routable. 5xx/timeout = problem.
		if ( $code >= 500 || $code === 0 ) {
			wp_send_json_error( sprintf( __( 'Server returned HTTP %d.', 'wp-lunapay' ), $code ) );
		}

		// Mark as tested
		$setup = get_option( 'wp_lunapay_setup', [] );
		$setup['webhook_reachable']  = true;
		$setup['webhook_tested_at']  = current_time( 'mysql' );
		update_option( 'wp_lunapay_setup', $setup );

		wp_send_json_success( sprintf( __( 'Reachable! (HTTP %d)', 'wp-lunapay' ), $code ) );
	}

	public static function ajax_create_test_order(): void {
		check_ajax_referer( 'wp_lunapay_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Permission denied' );

		// Get or create a simple test product
		$product_id = self::get_or_create_test_product();
		if ( ! $product_id ) {
			wp_send_json_error( __( 'Could not create a test product.', 'wp-lunapay' ) );
		}

		$order = wc_create_order();
		if ( is_wp_error( $order ) ) {
			wp_send_json_error( $order->get_error_message() );
		}

		$product = wc_get_product( $product_id );
		$order->add_product( $product, 1 );
		$order->set_payment_method( 'moonpay' );
		$order->set_payment_method_title( __( 'MoonPay (Test)', 'wp-lunapay' ) );
		$order->set_billing_email( get_option( 'admin_email' ) );
		$order->set_billing_first_name( 'Test' );
		$order->set_billing_last_name( 'Customer' );
		$order->set_address( [
			'first_name' => 'Test',
			'last_name'  => 'Customer',
			'email'      => get_option( 'admin_email' ),
			'country'    => 'US',
		], 'billing' );
		$order->set_currency( get_woocommerce_currency() );
		$order->calculate_totals();
		$order->set_status( 'pending', __( 'MoonPay test order created from Setup Wizard.', 'wp-lunapay' ) );
		$order->save();

		// Remember this test order
		$setup                  = get_option( 'wp_lunapay_setup', [] );
		$setup['test_order_id'] = $order->get_id();
		update_option( 'wp_lunapay_setup', $setup );

		wp_send_json_success( [
			'order_id'    => $order->get_id(),
			'order_url'   => $order->get_edit_order_url(),
			'payment_url' => $order->get_checkout_payment_url( true ),
		] );
	}

	public static function ajax_go_live(): void {
		check_ajax_referer( 'wp_lunapay_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Permission denied' );

		$opts             = get_option( 'woocommerce_moonpay_settings', [] );
		$opts['sandbox']  = 'no';
		update_option( 'woocommerce_moonpay_settings', $opts );

		$setup            = get_option( 'wp_lunapay_setup', [] );
		$setup['went_live_at'] = current_time( 'mysql' );
		update_option( 'wp_lunapay_setup', $setup );

		wp_send_json_success( admin_url( 'admin.php?page=wp-lunapay-setup&step=6&live=1' ) );
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private static function get_current_step(): int {
		$opts = get_option( 'woocommerce_moonpay_settings', [] );
		$setup = get_option( 'wp_lunapay_setup', [] );

		if ( empty( $opts['publishable_key'] ) ) return 1;
		if ( ! isset( $setup['webhook_reachable'] ) ) return 3;
		if ( empty( $setup['test_order_id'] ) ) return 5;
		return 6;
	}

	private static function get_setup_data(): array {
		$setup = get_option( 'wp_lunapay_setup', [] );

		// Inject last-webhook timestamp from the wp_lunapay_setup option
		// (populated by the wp_lunapay_webhook_processed hook in the main bootstrap).
		// If it's missing (e.g. plugin installed before this feature existed), derive it
		// from order meta using an HPOS-aware query.
		if ( empty( $setup['last_webhook_received'] ) ) {
			global $wpdb;
			$using_hpos = false;
			try {
				if ( class_exists( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class ) ) {
					$using_hpos = wc_get_container()
						->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )
						->custom_orders_table_usage_is_enabled();
				}
			} catch ( \Throwable $e ) {} // phpcs:ignore

			if ( $using_hpos ) {
				$last = $wpdb->get_var(
					"SELECT MAX(om.updated_at)
					 FROM {$wpdb->prefix}wc_orders_meta om
					 WHERE om.meta_key = '_moonpay_status' AND om.meta_value != ''"
				);
			} else {
				$last = $wpdb->get_var(
					"SELECT MAX(p.post_modified)
					 FROM {$wpdb->posts} p
					 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
					 WHERE pm.meta_key = '_moonpay_status' AND pm.meta_value != ''"
				);
			}

			if ( $last ) {
				$setup['last_webhook_received'] = $last;
				// Persist so we don't run this query every time
				update_option( 'wp_lunapay_setup', $setup );
			}
		}

		return $setup;
	}

	private static function get_or_create_test_product(): int {
		// Look for an existing test product
		$existing = get_posts( [
			'post_type'   => 'product',
			'meta_key'    => '_moonpay_test_product',
			'meta_value'  => '1',
			'numberposts' => 1,
			'fields'      => 'ids',
		] );

		if ( ! empty( $existing ) ) {
			return (int) $existing[0];
		}

		// Create a simple test product
		$product = new WC_Product_Simple();
		$product->set_name( __( 'MoonPay Test Product', 'wp-lunapay' ) );
		$product->set_regular_price( '10.00' );
		$product->set_status( 'private' ); // Hidden from shop
		$product->set_catalog_visibility( 'hidden' );
		$product->set_virtual( true );
		$product->update_meta_data( '_moonpay_test_product', '1' );
		$product->save();

		return $product->get_id();
	}

	private static function get_gateway(): ?WP_LunaPay_Gateway {
		$gateways = WC()->payment_gateways()->payment_gateways();
		return $gateways['moonpay'] ?? null;
	}
}
