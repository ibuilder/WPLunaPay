﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * Smart contextual admin notices.
 *
 * Shows the right notice for each incomplete setup step.
 * All notices are dismissible and remember their dismissed state per-user.
 */
class WP_LunaPay_Notices {

	public static function init(): void {
		add_action( 'admin_notices', [ self::class, 'render' ] );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue' ] );
		add_action( 'wp_ajax_wp_lunapay_dismiss_notice', [ self::class, 'ajax_dismiss' ] );
	}

	public static function enqueue(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) return;
		// Only load the dismiss JS when we will actually output notices
		wp_register_script(
			'wp-lunapay-notices',
			WP_LUNAPAY_PLUGIN_URL . 'assets/js/moonpay-admin.js',
			[ 'jquery' ],
			WP_LUNAPAY_VERSION,
			true
		);
		wp_localize_script( 'wp-lunapay-notices', 'wpLunaPayAdmin',
			WP_LunaPay_Setup_Wizard::js_data()
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) return;

		$opts    = get_option( 'woocommerce_moonpay_settings', [] );
		$setup   = get_option( 'wp_lunapay_setup', [] );
		$user_id = get_current_user_id();

		$has_keys       = ! empty( $opts['publishable_key'] ) && ! empty( $opts['secret_key'] );
		$is_enabled     = ( $opts['enabled'] ?? 'no' ) === 'yes';
		$is_sandbox     = ( $opts['sandbox'] ?? 'yes' ) === 'yes';
		$webhook_tested = ! empty( $setup['webhook_reachable'] );
		$test_done      = ! empty( $setup['test_order_id'] );
		$went_live      = ! empty( $setup['went_live_at'] );

		$wizard_url   = admin_url( 'admin.php?page=wp-lunapay-setup' );
		$settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=moonpay' );

		// ---- Notice 1: Keys not configured ----
		if ( ! $has_keys && ! self::is_dismissed( 'no_keys', $user_id ) ) {
			self::output(
				'no_keys',
				'warning',
				sprintf(
					/* translators: %s = wizard link */
					__( '<strong>MoonPay Gateway:</strong> API keys are not configured. <a href="%s">Open Setup Wizard →</a>', 'wp-lunapay' ),
					esc_url( $wizard_url . '&step=2' )
				)
			);
			wp_enqueue_script( 'wp-lunapay-notices' );
			return; // Show one notice at a time — don't overwhelm
		}

		// ---- Notice 2: Enabled but webhook not tested ----
		if ( $has_keys && $is_enabled && ! $webhook_tested && ! self::is_dismissed( 'no_webhook', $user_id ) ) {
			self::output(
				'no_webhook',
				'info',
				sprintf(
					__( '<strong>MoonPay Gateway:</strong> Webhook URL has not been tested. Orders won\'t update automatically until it\'s registered in your MoonPay dashboard. <a href="%s">Register webhook →</a>', 'wp-lunapay' ),
					esc_url( $wizard_url . '&step=3' )
				)
			);
			wp_enqueue_script( 'wp-lunapay-notices' );
			return;
		}

		// ---- Notice 3: No test order run yet ----
		if ( $has_keys && $is_enabled && $webhook_tested && ! $test_done && ! self::is_dismissed( 'no_test', $user_id ) ) {
			self::output(
				'no_test',
				'info',
				sprintf(
					__( '<strong>MoonPay Gateway:</strong> No test order has been run. Verify the full payment flow before going live. <a href="%s">Create test order →</a>', 'wp-lunapay' ),
					esc_url( $wizard_url . '&step=5' )
				)
			);
			wp_enqueue_script( 'wp-lunapay-notices' );
			return;
		}

		// ---- Notice 4: Sandbox mode reminder (on payment settings page only) ----
		$screen = get_current_screen();
		$on_settings = $screen && strpos( $screen->id ?? '', 'wc-settings' ) !== false;

		if ( $has_keys && $is_sandbox && $on_settings && ! $went_live && ! self::is_dismissed( 'sandbox_reminder', $user_id ) ) {
			self::output(
				'sandbox_reminder',
				'warning',
				sprintf(
					__( '<strong>MoonPay Gateway is in Sandbox mode.</strong> No real money is processed. <a href="%s">Switch to Live →</a>', 'wp-lunapay' ),
					esc_url( $wizard_url . '&step=6' )
				)
			);
			wp_enqueue_script( 'wp-lunapay-notices' );
		}

		// ---- Notice 5: All done / went live ----
		if ( $went_live && ! self::is_dismissed( 'went_live', $user_id ) ) {
			self::output(
				'went_live',
				'success',
				__( '<strong>MoonPay Gateway is Live!</strong> Your store is now accepting real cryptocurrency payments.', 'wp-lunapay' )
			);
			wp_enqueue_script( 'wp-lunapay-notices' );
		}
	}

	// -------------------------------------------------------------------------
	// AJAX dismiss
	// -------------------------------------------------------------------------

	public static function ajax_dismiss(): void {
		check_ajax_referer( 'wp_lunapay_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error();

		$notice_id = sanitize_key( $_POST['notice_id'] ?? '' );
		if ( ! $notice_id ) wp_send_json_error();

		$dismissed   = get_user_meta( get_current_user_id(), 'wp_lunapay_dismissed_notices', true ) ?: [];
		$dismissed[] = $notice_id;
		update_user_meta( get_current_user_id(), 'wp_lunapay_dismissed_notices', array_unique( $dismissed ) );

		wp_send_json_success();
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private static function output( string $notice_id, string $type, string $message ): void {
		?>
		<div class="notice notice-<?php echo esc_attr( $type ); ?> is-dismissible moonpay-admin-notice"
			data-notice-id="<?php echo esc_attr( $notice_id ); ?>">
			<p><?php echo wp_kses_post( $message ); ?></p>
		</div>
		<?php
	}

	private static function is_dismissed( string $notice_id, int $user_id ): bool {
		$dismissed = get_user_meta( $user_id, 'wp_lunapay_dismissed_notices', true ) ?: [];
		return in_array( $notice_id, (array) $dismissed, true );
	}
}
