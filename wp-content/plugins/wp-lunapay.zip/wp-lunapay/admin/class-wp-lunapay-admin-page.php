﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * Adds a MoonPay admin menu page under WooCommerce with an overview
 * of all orders paid via MoonPay, stats, and quick-links.
 */
class WP_LunaPay_Admin_Page {

	public static function init(): void {
		add_action( 'admin_menu', [ self::class, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
		add_action( 'admin_init', [ self::class, 'handle_csv_export' ] );
	}

	public static function register_menu(): void {
		add_submenu_page(
			'woocommerce',
			__( 'MoonPay Transactions', 'wp-lunapay' ),
			__( 'MoonPay', 'wp-lunapay' ),
			'manage_woocommerce',
			'wp-lunapay-transactions',
			[ self::class, 'render_page' ]
		);
	}

	public static function enqueue_assets( string $hook ): void {
		if ( $hook !== 'woocommerce_page_wp-lunapay-transactions' ) {
			return;
		}
		wp_enqueue_style(
			'wp-lunapay-admin',
			WP_LUNAPAY_PLUGIN_URL . 'assets/css/moonpay-admin.css',
			[],
			WP_LUNAPAY_VERSION
		);
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'wp-lunapay' ) );
		}

		// Pagination
		$per_page     = 20;
		$current_page = max( 1, absint( $_GET['paged'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification

		// Build WC_Order_Query args
		$query_args = [
			'payment_method' => 'moonpay',
			'limit'          => $per_page,
			'paged'          => $current_page,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'return'         => 'objects',
		];

		$orders     = wc_get_orders( $query_args );
		$total_args = array_merge( $query_args, [ 'limit' => -1, 'return' => 'ids' ] );
		$all_ids    = wc_get_orders( $total_args );
		$total      = is_array( $all_ids ) ? count( $all_ids ) : 0;
		$num_pages  = max( 1, (int) ceil( $total / $per_page ) );

		// Stats: count by moonpay status
		$stats = self::get_stats();

		$settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=moonpay' );
		$export_url   = wp_nonce_url(
			admin_url( 'admin.php?page=wp-lunapay-transactions&action=export_csv' ),
			'wp_lunapay_export_csv'
		);
		$wizard_url   = admin_url( 'admin.php?page=wp-lunapay-setup' );

		?>
		<div class="wrap moonpay-admin-wrap">
			<h1 class="wp-heading-inline">
				<?php esc_html_e( 'MoonPay Transactions', 'wp-lunapay' ); ?>
			</h1>
			<a href="<?php echo esc_url( $settings_url ); ?>" class="page-title-action">
				<?php esc_html_e( 'Gateway Settings', 'wp-lunapay' ); ?>
			</a>
			<a href="<?php echo esc_url( $wizard_url ); ?>" class="page-title-action">
				<?php esc_html_e( 'Setup Wizard', 'wp-lunapay' ); ?>
			</a>
			<a href="<?php echo esc_url( $export_url ); ?>" class="page-title-action">
				⬇ <?php esc_html_e( 'Export CSV', 'wp-lunapay' ); ?>
			</a>
			<hr class="wp-header-end">

			<?php // Gateway status notice ?>
			<?php
			$gateway  = WC()->payment_gateways()->payment_gateways()['moonpay'] ?? null;
			$is_live  = $gateway && ! $gateway->is_sandbox();
			$has_keys = $gateway && ! empty( $gateway->get_option( 'publishable_key' ) );
			?>
			<?php if ( ! $has_keys ) : ?>
			<div class="notice notice-warning inline">
				<p>
					<?php esc_html_e( 'MoonPay API keys are not configured.', 'wp-lunapay' ); ?>
					<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Configure now →', 'wp-lunapay' ); ?></a>
				</p>
			</div>
			<?php elseif ( ! $is_live ) : ?>
			<div class="notice notice-info inline">
				<p><?php esc_html_e( 'MoonPay is in Sandbox (test) mode.', 'wp-lunapay' ); ?></p>
			</div>
			<?php endif; ?>

			<?php // Stats cards ?>
			<div class="moonpay-stats-row">
				<div class="moonpay-stat-card">
					<div class="moonpay-stat-number"><?php echo esc_html( $stats['total'] ); ?></div>
					<div class="moonpay-stat-label"><?php esc_html_e( 'Total Orders', 'wp-lunapay' ); ?></div>
				</div>
				<div class="moonpay-stat-card">
					<div class="moonpay-stat-number"><?php echo esc_html( $stats['completed'] ); ?></div>
					<div class="moonpay-stat-label"><?php esc_html_e( 'Completed', 'wp-lunapay' ); ?></div>
				</div>
				<div class="moonpay-stat-card">
					<div class="moonpay-stat-number"><?php echo esc_html( $stats['pending'] ); ?></div>
					<div class="moonpay-stat-label"><?php esc_html_e( 'Pending', 'wp-lunapay' ); ?></div>
				</div>
				<div class="moonpay-stat-card">
					<div class="moonpay-stat-number"><?php echo esc_html( $stats['failed'] ); ?></div>
					<div class="moonpay-stat-label"><?php esc_html_e( 'Failed / Cancelled', 'wp-lunapay' ); ?></div>
				</div>
				<div class="moonpay-stat-card">
					<div class="moonpay-stat-number"><?php echo wc_price( $stats['revenue'] ); // phpcs:ignore ?></div>
					<div class="moonpay-stat-label"><?php esc_html_e( 'Total Revenue', 'wp-lunapay' ); ?></div>
				</div>
			</div>

			<?php // Orders table ?>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Order', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'Date', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'Total', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'WC Status', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'MoonPay Status', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'Transaction ID', 'wp-lunapay' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'wp-lunapay' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $orders ) ) : ?>
					<tr>
						<td colspan="8">
							<?php esc_html_e( 'No MoonPay orders found.', 'wp-lunapay' ); ?>
						</td>
					</tr>
					<?php else : ?>
					<?php foreach ( $orders as $order ) :
						$mp_status = $order->get_meta( '_moonpay_status' ) ?: '—';
						$mp_tx_id  = $order->get_meta( '_moonpay_transaction_id' ) ?: '—';
						$edit_url  = $order->get_edit_order_url();
						$customer  = $order->get_formatted_billing_full_name() ?: $order->get_billing_email();
					?>
					<tr>
						<td>
							<a href="<?php echo esc_url( $edit_url ); ?>">
								#<?php echo esc_html( $order->get_order_number() ); ?>
							</a>
						</td>
						<td><?php echo esc_html( $customer ); ?></td>
						<td><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></td>
						<td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
						<td>
							<mark class="order-status status-<?php echo esc_attr( $order->get_status() ); ?>">
								<span><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
							</mark>
						</td>
						<td>
							<?php if ( $mp_status !== '—' ) : ?>
							<span class="moonpay-badge moonpay-status-<?php echo esc_attr( $mp_status ); ?>">
								<?php echo esc_html( ucfirst( $mp_status ) ); ?>
							</span>
							<?php else : ?>
							<span style="color:#aaa;">—</span>
							<?php endif; ?>
						</td>
						<td>
							<?php if ( $mp_tx_id !== '—' ) : ?>
							<code style="font-size:10px;"><?php echo esc_html( substr( $mp_tx_id, 0, 16 ) ); ?>…</code>
							<?php else : ?>
							<span style="color:#aaa;">—</span>
							<?php endif; ?>
						</td>
						<td>
							<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small">
								<?php esc_html_e( 'View', 'wp-lunapay' ); ?>
							</a>
						</td>
					</tr>
					<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php // Pagination ?>
			<?php if ( $num_pages > 1 ) :
				$base_url = admin_url( 'admin.php?page=wp-lunapay-transactions' );
				?>
			<div class="tablenav bottom">
				<div class="tablenav-pages">
					<span class="displaying-num">
						<?php printf(
							/* translators: %d = total orders */
							esc_html( _n( '%d order', '%d orders', $total, 'wp-lunapay' ) ),
							(int) $total
						); ?>
					</span>
					<span class="pagination-links">
						<?php for ( $p = 1; $p <= $num_pages; $p++ ) :
							$url = add_query_arg( 'paged', $p, $base_url );
							$cls = $p === $current_page ? 'button button-primary' : 'button';
						?>
						<a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( $cls ); ?>"><?php echo esc_html( $p ); ?></a>
						<?php endfor; ?>
					</span>
				</div>
			</div>
			<?php endif; ?>

		<?php self::render_credit_footer(); ?>
		</div>
		<?php
	}

	/**
	 * Render the WPLunaPay credit footer.
	 */
	public static function render_credit_footer(): void {
		?>
		<div class="moonpay-admin-credit">
			<?php printf(
				/* translators: %s = link */
				esc_html__( 'MoonPay Crypto Payments — developed by %s', 'wp-lunapay' ),
				'<a href="https://wprealwise.com" target="_blank" rel="noopener">wprealwise.com</a>'
			); ?>
		</div>
		<?php
	}

	/**
	 * Compute summary stats across all MoonPay orders.
	 *
	 * Uses IDs-only queries and direct DB aggregation to avoid loading
	 * thousands of WC_Order objects into memory (memory bomb prevention).
	 */
	private static function get_stats(): array {
		$stats = [
			'total'     => 0,
			'completed' => 0,
			'pending'   => 0,
			'failed'    => 0,
			'revenue'   => 0.0,
		];

		// Count total MoonPay orders (IDs only — cheap)
		$all_ids = wc_get_orders( [
			'payment_method' => 'moonpay',
			'limit'          => -1,
			'return'         => 'ids',
		] );

		$stats['total'] = is_array( $all_ids ) ? count( $all_ids ) : 0;

		if ( $stats['total'] === 0 ) {
			return $stats;
		}

		// Aggregate by moonpay status via direct meta query (avoids loading objects)
		global $wpdb;

		$using_hpos = false;
		try {
			if ( class_exists( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class ) ) {
				$using_hpos = wc_get_container()
					->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )
					->custom_orders_table_usage_is_enabled();
			}
		} catch ( \Throwable $e ) {
			// Ignore; fall back to post_meta
		}

		if ( $using_hpos ) {
			// HPOS: meta stored in wc_orders_meta
			$meta_table = $wpdb->prefix . 'wc_orders_meta';
			$rows       = $wpdb->get_results(
				"SELECT meta_value AS mp_status, COUNT(*) AS cnt
				 FROM {$meta_table}
				 WHERE meta_key = '_moonpay_status'
				 GROUP BY meta_value"
			);
		} else {
			// Classic: meta stored in postmeta
			$rows = $wpdb->get_results(
				"SELECT meta_value AS mp_status, COUNT(*) AS cnt
				 FROM {$wpdb->postmeta}
				 WHERE meta_key = '_moonpay_status'
				 GROUP BY meta_value"
			);
		}

		foreach ( $rows as $row ) {
			if ( $row->mp_status === 'completed' ) {
				$stats['completed'] += (int) $row->cnt;
			} elseif ( in_array( $row->mp_status, [ 'failed', 'cancelled' ], true ) ) {
				$stats['failed'] += (int) $row->cnt;
			} else {
				$stats['pending'] += (int) $row->cnt;
			}
		}

		// Revenue: sum order totals for completed MoonPay orders only
		// Fetch completed order IDs and sum via a targeted meta query
		$completed_ids = wc_get_orders( [
			'payment_method' => 'moonpay',
			'status'         => [ 'wc-processing', 'wc-completed' ],
			'limit'          => -1,
			'return'         => 'ids',
		] );

		if ( ! empty( $completed_ids ) ) {
			$id_placeholders = implode( ',', array_map( 'absint', $completed_ids ) );

			if ( $using_hpos ) {
				$revenue = $wpdb->get_var(
					"SELECT SUM(total_amount)
					 FROM {$wpdb->prefix}wc_orders
					 WHERE id IN ({$id_placeholders})" // phpcs:ignore WordPress.DB.PreparedSQL
				);
			} else {
				$revenue = $wpdb->get_var(
					"SELECT SUM(meta_value)
					 FROM {$wpdb->postmeta}
					 WHERE meta_key = '_order_total'
					   AND post_id IN ({$id_placeholders})" // phpcs:ignore WordPress.DB.PreparedSQL
				);
			}

			$stats['revenue'] = (float) ( $revenue ?? 0 );
		}

		return $stats;
	}

	/**
	 * Handle CSV export download — fires on admin_init before output begins.
	 */
	public static function handle_csv_export(): void {
		if (
			! isset( $_GET['page'], $_GET['action'] ) ||
			$_GET['page'] !== 'wp-lunapay-transactions' ||
			$_GET['action'] !== 'export_csv'
		) {
			return;
		}

		check_admin_referer( 'wp_lunapay_export_csv' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'wp-lunapay' ) );
		}

		$orders = wc_get_orders( [
			'payment_method' => 'moonpay',
			'limit'          => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'return'         => 'objects',
		] );

		$filename = 'moonpay-transactions-' . gmdate( 'Y-m-d' ) . '.csv';

		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$out = fopen( 'php://output', 'w' );

		// UTF-8 BOM so Excel opens it correctly
		fputs( $out, "\xEF\xBB\xBF" );

		fputcsv( $out, [
			'Order ID',
			'Order Number',
			'Date',
			'Customer Name',
			'Customer Email',
			'Total',
			'Currency',
			'WC Status',
			'MoonPay Status',
			'MoonPay Transaction ID',
		] );

		foreach ( $orders as $order ) {
			fputcsv( $out, [
				$order->get_id(),
				$order->get_order_number(),
				$order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
				$order->get_formatted_billing_full_name(),
				$order->get_billing_email(),
				$order->get_total(),
				$order->get_currency(),
				$order->get_status(),
				$order->get_meta( '_moonpay_status' ),
				$order->get_meta( '_moonpay_transaction_id' ),
			] );
		}

		fclose( $out );
		exit;
	}
}
