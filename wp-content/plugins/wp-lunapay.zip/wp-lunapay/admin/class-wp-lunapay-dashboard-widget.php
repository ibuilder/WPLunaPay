﻿<?php
defined( 'ABSPATH' ) || exit;

/**
 * WordPress Dashboard Widget — shows MoonPay setup progress and live stats
 * on the main /wp-admin dashboard visible to shop managers and admins.
 */
class WP_LunaPay_Dashboard_Widget {

	public static function init(): void {
		add_action( 'wp_dashboard_setup', [ self::class, 'register' ] );
	}

	public static function register(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'wp_lunapay_dashboard_widget',
			__( 'MoonPay Payments', 'wp-lunapay' ),
			[ self::class, 'render' ]
		);
	}

	public static function render(): void {
		$gateway    = self::get_gateway();
		$opts       = get_option( 'woocommerce_moonpay_settings', [] );
		$setup      = get_option( 'wp_lunapay_setup', [] );
		$has_keys   = ! empty( $opts['publishable_key'] ) && ! empty( $opts['secret_key'] );
		$is_sandbox = ( $opts['sandbox'] ?? 'yes' ) === 'yes';
		$is_enabled = ( $opts['enabled'] ?? 'no' ) === 'yes';
		$wizard_url = admin_url( 'admin.php?page=wp-lunapay-setup' );
		$txn_url    = admin_url( 'admin.php?page=wp-lunapay-transactions' );
		$settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=moonpay' );

		// ---- Setup checklist ----
		$checklist = self::build_checklist( $has_keys, $is_enabled, $setup );
		$done_count = count( array_filter( array_column( $checklist, 'done' ) ) );
		$total      = count( $checklist );
		$all_done   = ( $done_count === $total );

		echo '<div class="moonpay-dash-widget">';

		// Environment pill
		if ( $is_enabled ) {
			if ( $is_sandbox ) {
				echo '<span class="moonpay-dash-pill moonpay-dash-pill--sandbox">' . esc_html__( 'Sandbox', 'wp-lunapay' ) . '</span>';
			} else {
				echo '<span class="moonpay-dash-pill moonpay-dash-pill--live">' . esc_html__( 'Live', 'wp-lunapay' ) . '</span>';
			}
		} else {
			echo '<span class="moonpay-dash-pill moonpay-dash-pill--disabled">' . esc_html__( 'Disabled', 'wp-lunapay' ) . '</span>';
		}

		// ---- Setup progress ----
		if ( ! $all_done ) {
			echo '<div class="moonpay-dash-section">';
			echo '<h4>' . esc_html__( 'Setup Progress', 'wp-lunapay' ) . '</h4>';
			echo '<div class="moonpay-dash-progress-bar"><div class="moonpay-dash-progress-fill" style="width:' . esc_attr( round( $done_count / $total * 100 ) ) . '%"></div></div>';
			echo '<ul class="moonpay-dash-checklist">';
			foreach ( $checklist as $item ) {
				$icon = $item['done'] ? '✓' : '○';
				$cls  = $item['done'] ? 'done' : 'todo';
				echo '<li class="moonpay-dash-check ' . esc_attr( $cls ) . '">';
				echo '<span class="moonpay-dash-check-icon">' . esc_html( $icon ) . '</span> ';
				echo '<span>' . esc_html( $item['label'] ) . '</span>';
				if ( ! $item['done'] && ! empty( $item['action_url'] ) ) {
					echo ' <a href="' . esc_url( $item['action_url'] ) . '" class="moonpay-dash-check-link">' . esc_html( $item['action_label'] ) . '</a>';
				}
				echo '</li>';
			}
			echo '</ul>';
			echo '<a href="' . esc_url( $wizard_url ) . '" class="button button-primary moonpay-dash-wizard-btn">' . esc_html__( 'Open Setup Wizard', 'wp-lunapay' ) . '</a>';
			echo '</div>';
		}

		// ---- Live stats (only show when keys configured) ----
		if ( $has_keys ) {
			$stats = self::get_quick_stats();
			echo '<div class="moonpay-dash-section">';
			echo '<h4>' . esc_html__( 'Last 30 Days', 'wp-lunapay' ) . '</h4>';
			echo '<div class="moonpay-dash-stats">';
			echo '<div class="moonpay-dash-stat"><span class="moonpay-dash-stat-num">' . esc_html( $stats['orders_30d'] ) . '</span><span class="moonpay-dash-stat-lbl">' . esc_html__( 'Orders', 'wp-lunapay' ) . '</span></div>';
			echo '<div class="moonpay-dash-stat"><span class="moonpay-dash-stat-num">' . wp_kses_post( wc_price( $stats['revenue_30d'] ) ) . '</span><span class="moonpay-dash-stat-lbl">' . esc_html__( 'Revenue', 'wp-lunapay' ) . '</span></div>';
			echo '<div class="moonpay-dash-stat"><span class="moonpay-dash-stat-num">' . esc_html( $stats['pending'] ) . '</span><span class="moonpay-dash-stat-lbl">' . esc_html__( 'Pending', 'wp-lunapay' ) . '</span></div>';
			echo '</div>';
			echo '</div>';
		}

		// ---- Quick links ----
		echo '<div class="moonpay-dash-links">';
		echo '<a href="' . esc_url( $txn_url ) . '">' . esc_html__( 'All Transactions', 'wp-lunapay' ) . '</a>';
		echo ' · <a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'wp-lunapay' ) . '</a>';
		echo ' · <a href="' . esc_url( $wizard_url ) . '">' . esc_html__( 'Setup Wizard', 'wp-lunapay' ) . '</a>';
		echo ' · <a href="https://dashboard.moonpay.com" target="_blank" rel="noopener">' . esc_html__( 'MoonPay Dashboard ↗', 'wp-lunapay' ) . '</a>';
		echo '</div>';

		// ---- WPLunaPay credit ----
		echo '<div style="margin-top:10px;font-size:10px;color:#ccc;text-align:right;">';
		echo '<a href="https://wprealwise.com" target="_blank" rel="noopener" style="color:#bbb;text-decoration:none;">wprealwise.com</a>';
		echo '</div>';

		echo '</div>'; // .moonpay-dash-widget
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private static function build_checklist( bool $has_keys, bool $is_enabled, array $setup ): array {
		$wizard_url   = admin_url( 'admin.php?page=wp-lunapay-setup' );
		$settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=moonpay' );

		return [
			[
				'done'         => $has_keys,
				'label'        => __( 'API keys configured', 'wp-lunapay' ),
				'action_url'   => $wizard_url . '&step=2',
				'action_label' => __( 'Add keys →', 'wp-lunapay' ),
			],
			[
				'done'         => $is_enabled,
				'label'        => __( 'Gateway enabled', 'wp-lunapay' ),
				'action_url'   => $settings_url,
				'action_label' => __( 'Enable →', 'wp-lunapay' ),
			],
			[
				'done'         => ! empty( $setup['webhook_reachable'] ),
				'label'        => __( 'Webhook URL registered & reachable', 'wp-lunapay' ),
				'action_url'   => $wizard_url . '&step=3',
				'action_label' => __( 'Register →', 'wp-lunapay' ),
			],
			[
				'done'         => ! empty( $setup['test_order_id'] ),
				'label'        => __( 'Test order completed', 'wp-lunapay' ),
				'action_url'   => $wizard_url . '&step=5',
				'action_label' => __( 'Run test →', 'wp-lunapay' ),
			],
			[
				'done'         => ! empty( $setup['went_live_at'] ),
				'label'        => __( 'Switched to live mode', 'wp-lunapay' ),
				'action_url'   => $wizard_url . '&step=6',
				'action_label' => __( 'Go live →', 'wp-lunapay' ),
			],
		];
	}

	private static function get_quick_stats(): array {
		// All MoonPay order IDs in last 30 days (IDs only — lightweight)
		$orders_30d = wc_get_orders( [
			'payment_method' => 'moonpay',
			'date_created'   => '>' . strtotime( '-30 days' ),
			'limit'          => -1,
			'return'         => 'ids',
		] );

		$pending_ids = wc_get_orders( [
			'payment_method' => 'moonpay',
			'status'         => [ 'wc-pending' ],
			'limit'          => -1,
			'return'         => 'ids',
		] );

		// Revenue via direct DB SUM — never load WC_Order objects
		$revenue = 0.0;
		if ( ! empty( $orders_30d ) ) {
			global $wpdb;
			$using_hpos = false;
			try {
				if ( class_exists( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class ) ) {
					$using_hpos = wc_get_container()
						->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )
						->custom_orders_table_usage_is_enabled();
				}
			} catch ( \Throwable $e ) {} // phpcs:ignore

			$ids_csv = implode( ',', array_map( 'absint', $orders_30d ) );

			if ( $using_hpos ) {
				$revenue = (float) $wpdb->get_var(
					"SELECT SUM(total_amount)
					 FROM {$wpdb->prefix}wc_orders
					 WHERE id IN ({$ids_csv})
					   AND status IN ('wc-processing','wc-completed')" // phpcs:ignore WordPress.DB.PreparedSQL
				);
			} else {
				$revenue = (float) $wpdb->get_var(
					"SELECT SUM(pm.meta_value)
					 FROM {$wpdb->postmeta} pm
					 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
					 WHERE pm.meta_key = '_order_total'
					   AND pm.post_id IN ({$ids_csv})
					   AND p.post_status IN ('wc-processing','wc-completed')" // phpcs:ignore WordPress.DB.PreparedSQL
				);
			}
		}

		return [
			'orders_30d'  => count( $orders_30d ),
			'revenue_30d' => $revenue,
			'pending'     => count( $pending_ids ),
		];
	}

	private static function get_gateway(): ?WP_LunaPay_Gateway {
		$gateways = WC()->payment_gateways()->payment_gateways();
		return $gateways['moonpay'] ?? null;
	}
}
