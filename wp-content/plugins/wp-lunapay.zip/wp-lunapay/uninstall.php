﻿<?php
/**
 * Plugin uninstall — runs when the plugin is deleted via WP Admin → Plugins.
 * Only called when the user explicitly deletes the plugin (not on deactivation).
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// ---- Options ----
delete_option( 'woocommerce_moonpay_settings' ); // gateway settings
delete_option( 'wp_lunapay_db_version' );         // install version
delete_option( 'wp_lunapay_installed' );           // install timestamp
delete_option( 'wp_lunapay_setup' );               // wizard progress / setup state

// ---- Price transients ----
$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '_transient_wp_lunapay_price_%'
	    OR option_name LIKE '_transient_timeout_wp_lunapay_price_%'"
);

// ---- User meta (dismissed notices, per-user state) ----
$wpdb->delete( $wpdb->usermeta, [ 'meta_key' => 'wp_lunapay_dismissed_notices' ] );

// ---- Test product (private, hidden virtual product created by the wizard) ----
$test_product_ids = $wpdb->get_col(
	"SELECT post_id FROM {$wpdb->postmeta}
	 WHERE meta_key = '_moonpay_test_product' AND meta_value = '1'"
);
foreach ( $test_product_ids as $pid ) {
	wp_delete_post( (int) $pid, true ); // force delete (bypass trash)
}

// NOTE: We intentionally do NOT delete order meta (_moonpay_transaction_id, _moonpay_status, etc.)
// Order records belong to the merchant's business data and must be preserved for
// accounting, tax records, and dispute resolution even after the plugin is removed.
