﻿/* MoonPay Crypto Payments — Admin JS
 * Handles: Setup Wizard, API connection test, webhook reachability,
 *          copy-to-clipboard, test order creation, go-live modal, notice dismissal.
 * global wpLunaPayAdmin, jQuery
 */

(function ($) {
	'use strict';

	if ( typeof wpLunaPayAdmin === 'undefined' ) return;

	var ajax = wpLunaPayAdmin.ajaxUrl;
	var nonce = wpLunaPayAdmin.nonce;
	var i18n = wpLunaPayAdmin.i18n;

	// =========================================================================
	// Utility helpers
	// =========================================================================

	function setResult( $el, msg, ok ) {
		$el.text( msg )
		   .css( 'color', ok ? '#1a7f37' : '#cf222e' )
		   .show();
	}

	function setBtn( $btn, label, disabled ) {
		$btn.prop( 'disabled', disabled ).text( label );
	}

	// =========================================================================
	// Step 2 — Test Connection
	// =========================================================================

	$( document ).on( 'click', '#moonpay-test-connection', function () {
		var $btn    = $( this );
		var $result = $( '#moonpay-test-result' );
		var pub     = $( '#mp_pub_key' ).val().trim();
		var sec     = $( '#mp_sec_key' ).val().trim();
		var sandbox = $( '#mp_sandbox' ).is( ':checked' ) ? 'yes' : 'no';

		if ( ! pub || ! sec ) {
			setResult( $result, i18n.enterBothKeys, false );
			return;
		}

		setBtn( $btn, i18n.testing, true );
		$result.hide();

		$.post( ajax, {
			action:          'wp_lunapay_test_connection',
			nonce:           nonce,
			publishable_key: pub,
			secret_key:      sec,
			sandbox:         sandbox,
		} )
		.done( function ( res ) {
			setResult( $result, ( res.success ? '✓ ' : '✗ ' ) + ( res.data || ( res.success ? i18n.connected : i18n.failed ) ), res.success );
		} )
		.fail( function () {
			setResult( $result, '✗ ' + i18n.failed + ' (network error)', false );
		} )
		.always( function () {
			setBtn( $btn, i18n.btnTestConnection, false );
		} );
	} );

	// =========================================================================
	// Step 2 — Save Keys
	// =========================================================================

	$( document ).on( 'click', '#moonpay-save-keys', function () {
		var $btn    = $( this );
		var $result = $( '#moonpay-test-result' );
		var pub     = $( '#mp_pub_key' ).val().trim();
		var sec     = $( '#mp_sec_key' ).val().trim();
		var sandbox = $( '#mp_sandbox' ).is( ':checked' ) ? 'yes' : 'no';

		if ( ! pub || ! sec ) {
			setResult( $result, i18n.enterBothKeys, false );
			return;
		}

		setBtn( $btn, i18n.saving, true );
		$result.hide();

		$.post( ajax, {
			action:          'wp_lunapay_save_wizard_step',
			nonce:           nonce,
			wizard_step:     'keys',
			publishable_key: pub,
			secret_key:      sec,
			sandbox:         sandbox,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				setResult( $result, '✓ ' + res.data, true );
				setTimeout( function () {
					window.location.href = wpLunaPayAdmin.wizardUrl + '&step=3';
				}, 800 );
			} else {
				setResult( $result, '✗ ' + ( res.data || i18n.failed ), false );
				setBtn( $btn, i18n.btnSaveKeys, false );
			}
		} )
		.fail( function () {
			setResult( $result, '✗ ' + i18n.failed + ' (network error)', false );
			setBtn( $btn, i18n.btnSaveKeys, false );
		} );
	} );

	// =========================================================================
	// Step 3 — Copy webhook URL
	// =========================================================================

	$( document ).on( 'click', '#moonpay-copy-webhook', function () {
		var $btn = $( this );
		var url  = $( '#moonpay-webhook-url-input' ).val();

		if ( navigator.clipboard && window.isSecureContext ) {
			navigator.clipboard.writeText( url ).then( function () {
				$btn.text( i18n.copied );
				setTimeout( function () { $btn.text( i18n.copy ); }, 2000 );
			} ).catch( function () {
				fallbackCopy( url, $btn );
			} );
		} else {
			fallbackCopy( url, $btn );
		}
	} );

	function fallbackCopy( text, $btn ) {
		var $tmp = $( '<textarea style="position:fixed;top:-9999px;opacity:0">' )
			.val( text )
			.appendTo( 'body' );
		$tmp.get(0).select();
		try {
			document.execCommand( 'copy' );
			$btn.text( i18n.copied );
			setTimeout( function () { $btn.text( i18n.copy ); }, 2000 );
		} catch ( e ) {
			// Cannot copy — nothing to do
		}
		$tmp.remove();
	}

	// =========================================================================
	// Step 3 — Test Webhook Reachability
	// =========================================================================

	$( document ).on( 'click', '#moonpay-test-webhook-reachability', function () {
		var $btn    = $( this );
		var $result = $( '#moonpay-webhook-reach-result' );

		setBtn( $btn, i18n.testing, true );
		$result.hide();

		$.post( ajax, {
			action: 'wp_lunapay_test_webhook_url',
			nonce:  nonce,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				setResult( $result, '✓ ' + ( res.data || i18n.reachable ), true );
				// Update status indicators without reload
				$( '.moonpay-wizard-status-item' ).first()
					.removeClass( 'pending' ).addClass( 'ok' )
					.find( '.moonpay-wizard-status-icon' ).text( '✓' );
			} else {
				setResult( $result, '✗ ' + ( res.data || i18n.notReachable ), false );
			}
		} )
		.fail( function () {
			setResult( $result, '✗ ' + i18n.failed + ' (network error)', false );
		} )
		.always( function () {
			setBtn( $btn, i18n.btnTestReachability, false );
		} );
	} );

	// =========================================================================
	// Step 4 — Save Config
	// =========================================================================

	$( document ).on( 'click', '#moonpay-save-config', function () {
		var $btn    = $( this );
		var $result = $( '#moonpay-config-result' );

		setBtn( $btn, i18n.saving, true );
		$result.hide();

		$.post( ajax, {
			action:          'wp_lunapay_save_wizard_step',
			nonce:           nonce,
			wizard_step:     'config',
			widget_mode:     $( '#mp_widget_mode' ).val(),
			default_crypto:  $( '#mp_default_crypto' ).val().trim(),
			allowed_cryptos: $( '#mp_allowed_cryptos' ).val().trim(),
			color_code:      $( '#mp_color_code' ).val(),
			title:           $( '#mp_title' ).val().trim(),
			description:     $( '#mp_description' ).val().trim(),
		} )
		.done( function ( res ) {
			if ( res.success ) {
				setResult( $result, '✓ ' + res.data, true );
				setTimeout( function () {
					window.location.href = wpLunaPayAdmin.wizardUrl + '&step=5';
				}, 800 );
			} else {
				setResult( $result, '✗ ' + ( res.data || i18n.failed ), false );
				setBtn( $btn, i18n.btnSaveConfig, false );
			}
		} )
		.fail( function () {
			setResult( $result, '✗ ' + i18n.failed + ' (network error)', false );
			setBtn( $btn, i18n.btnSaveConfig, false );
		} );
	} );

	// =========================================================================
	// Step 5 — Create Test Order
	// =========================================================================

	$( document ).on( 'click', '#moonpay-create-test-order', function () {
		var $btn    = $( this );
		var $result = $( '#moonpay-test-order-result' );

		setBtn( $btn, i18n.creating, true );
		$result.empty().hide();

		$.post( ajax, {
			action: 'wp_lunapay_create_test_order',
			nonce:  nonce,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				var d = res.data;
				$result
					.html(
						'<div class="moonpay-wizard-callout moonpay-wizard-callout--success">' +
						'&#10003; ' + i18n.testOrderCreated.replace( '%id%', d.order_id ) + ' ' +
						'<a href="' + d.payment_url + '" target="_blank" rel="noopener">' + i18n.openCheckout + '</a> &nbsp; ' +
						'<a href="' + d.order_url + '" target="_blank" rel="noopener">' + i18n.viewInAdmin + '</a>' +
						'</div>'
					)
					.show();
				setBtn( $btn, i18n.btnAnotherTestOrder, false );
			} else {
				setResult( $result, '✗ ' + ( res.data || i18n.failed ), false );
				$result.show();
				setBtn( $btn, i18n.btnCreateTestOrder, false );
			}
		} )
		.fail( function () {
			setResult( $result, '✗ ' + i18n.failed + ' (network error)', false );
			$result.show();
			setBtn( $btn, i18n.btnCreateTestOrder, false );
		} );
	} );

	// =========================================================================
	// Step 6 — Go Live confirmation
	// =========================================================================

	$( document ).on( 'click', '#moonpay-go-live-btn, .moonpay-go-live-btn', function () {
		if ( ! window.confirm( i18n.confirmGoLive ) ) return;

		var $btn = $( this );
		setBtn( $btn, i18n.goingLive, true );

		$.post( ajax, {
			action: 'wp_lunapay_go_live',
			nonce:  nonce,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				window.location.href = res.data;
			} else {
				alert( '✗ ' + ( res.data || i18n.failed ) );
				setBtn( $btn, i18n.btnGoLive, false );
			}
		} )
		.fail( function () {
			alert( '✗ ' + i18n.failed + ' (network error)' );
			setBtn( $btn, i18n.btnGoLive, false );
		} );
	} );

	// =========================================================================
	// Admin notice — persist dismissal via AJAX
	// =========================================================================

	$( document ).on( 'click', '.moonpay-admin-notice .notice-dismiss', function () {
		var notice_id = $( this ).closest( '.moonpay-admin-notice' ).data( 'notice-id' );
		if ( ! notice_id ) return;
		$.post( ajax, {
			action:    'wp_lunapay_dismiss_notice',
			nonce:     nonce,
			notice_id: notice_id,
		} );
		// WP's own handler hides the element — we just fire the persistence AJAX
	} );

	// =========================================================================
	// WC Settings page — confirm before disabling sandbox
	// =========================================================================

	$( document ).on( 'change', 'input[name="woocommerce_moonpay_sandbox"]', function () {
		if ( ! $( this ).is( ':checked' ) ) {
			if ( ! window.confirm( i18n.confirmGoLive ) ) {
				$( this ).prop( 'checked', true ); // revert
			}
		}
	} );

})(jQuery);
