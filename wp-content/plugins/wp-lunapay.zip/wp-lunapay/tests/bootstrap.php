<?php
/**
 * PHPUnit bootstrap — provides the minimal WordPress / WooCommerce stubs
 * needed to instantiate and test our plugin classes in isolation.
 *
 * We do NOT load a full WordPress installation. Only the functions actually
 * called by the classes under test are stubbed here.
 */

// ---- Stop plugin files from exiting ----
define( 'ABSPATH', dirname( __DIR__ ) . '/' );
define( 'WP_LUNAPAY_PLUGIN_DIR', dirname( __DIR__ ) . '/' );
define( 'WP_LUNAPAY_PLUGIN_URL', 'http://example.com/wp-content/plugins/wp-lunapay/' );
define( 'WP_LUNAPAY_VERSION', '1.0.0-test' );
define( 'WP_LUNAPAY_PLUGIN_FILE', dirname( __DIR__ ) . '/wp-lunapay.php' );

// ---- Composer autoloader ----
require_once dirname( __DIR__ ) . '/vendor/autoload.php';

// =========================================================================
// WordPress function stubs
// =========================================================================

if ( ! function_exists( 'add_query_arg' ) ) {
	function add_query_arg( array $args, string $url ): string {
		$query = http_build_query( $args, '', '&', PHP_QUERY_RFC3986 );
		return $url . ( str_contains( $url, '?' ) ? '&' : '?' ) . $query;
	}
}

if ( ! function_exists( 'wp_json_encode' ) ) {
	function wp_json_encode( $data ): string|false {
		return json_encode( $data );
	}
}

if ( ! function_exists( 'wp_remote_request' ) ) {
	/** Stub — individual tests override this via a global. */
	function wp_remote_request( string $url, array $args = [] ): array|WP_Error {
		return $GLOBALS['__wp_remote_request_stub'] ?? new WP_Error( 'not_mocked', 'Not mocked' );
	}
}

if ( ! function_exists( 'wp_remote_retrieve_body' ) ) {
	function wp_remote_retrieve_body( array|WP_Error $response ): string {
		return $response['body'] ?? '';
	}
}

if ( ! function_exists( 'wp_remote_retrieve_response_code' ) ) {
	function wp_remote_retrieve_response_code( array|WP_Error $response ): int {
		return $response['response']['code'] ?? 0;
	}
}

if ( ! function_exists( 'is_wp_error' ) ) {
	function is_wp_error( mixed $thing ): bool {
		return $thing instanceof WP_Error;
	}
}

if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( string $str ): string {
		return trim( strip_tags( $str ) );
	}
}

if ( ! function_exists( 'sanitize_key' ) ) {
	function sanitize_key( string $key ): string {
		return strtolower( preg_replace( '/[^a-z0-9_\-]/i', '', $key ) );
	}
}

if ( ! function_exists( 'sanitize_hex_color' ) ) {
	function sanitize_hex_color( string $color ): ?string {
		if ( preg_match( '/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/', $color ) ) {
			return $color;
		}
		return null;
	}
}

if ( ! function_exists( 'esc_url' ) ) {
	function esc_url( string $url ): string { return $url; }
}

if ( ! function_exists( 'esc_html' ) ) {
	function esc_html( string $text ): string { return htmlspecialchars( $text, ENT_QUOTES ); }
}

if ( ! function_exists( '__' ) ) {
	function __( string $text, string $domain = 'default' ): string { return $text; }
}

if ( ! function_exists( '_e' ) ) {
	function _e( string $text, string $domain = 'default' ): void { echo $text; }
}

if ( ! function_exists( 'esc_html__' ) ) {
	function esc_html__( string $text, string $domain = 'default' ): string { return $text; }
}

if ( ! function_exists( 'esc_attr' ) ) {
	function esc_attr( string $text ): string { return htmlspecialchars( $text, ENT_QUOTES ); }
}

if ( ! function_exists( 'absint' ) ) {
	function absint( mixed $val ): int { return abs( (int) $val ); }
}

if ( ! function_exists( 'sanitize_textarea_field' ) ) {
	function sanitize_textarea_field( string $str ): string { return trim( strip_tags( $str ) ); }
}

if ( ! function_exists( 'human_time_diff' ) ) {
	function human_time_diff( int $from, int $to = 0 ): string { return '1 minute'; }
}

// =========================================================================
// WordPress class stubs
// =========================================================================

if ( ! class_exists( 'WP_Error' ) ) {
	class WP_Error {
		private string $code;
		private string $message;
		private mixed  $data;

		public function __construct( string $code = '', string $message = '', mixed $data = '' ) {
			$this->code    = $code;
			$this->message = $message;
			$this->data    = $data;
		}

		public function get_error_code(): string    { return $this->code; }
		public function get_error_message(): string { return $this->message; }
		public function get_error_data(): mixed     { return $this->data; }
	}
}

// =========================================================================
// WooCommerce class stubs (minimal — only what our code touches)
// =========================================================================

if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
	abstract class WC_Payment_Gateway {
		public string $id          = '';
		public string $title       = '';
		public string $description = '';
		public string $enabled     = 'no';
		public bool   $has_fields  = false;
		public array  $supports    = [];
		protected array $settings  = [];

		protected function init_settings(): void {}
		protected function init_form_fields(): void {}

		public function get_option( string $key, mixed $default = '' ): mixed {
			return $this->settings[ $key ] ?? $default;
		}

		public function set_option( string $key, mixed $value ): void {
			$this->settings[ $key ] = $value;
		}
	}
}

if ( ! class_exists( 'WC_Order' ) ) {
	class WC_Order {
		private array  $meta     = [];
		private string $status   = 'pending';
		private string $payment  = '';

		public function get_id(): int                          { return 1; }
		public function get_status(): string                   { return $this->status; }
		public function get_payment_method(): string           { return $this->payment; }
		public function get_billing_email(): string            { return 'test@example.com'; }
		public function get_order_key(): string                { return 'wc_order_TestKey'; }
		public function get_total(): string                    { return '49.99'; }
		public function get_formatted_order_total(): string    { return '$49.99'; }
		public function get_checkout_payment_url( bool $on_checkout = false ): string { return 'http://example.com/checkout/order-pay/1/'; }
		public function get_return_url(): string               { return 'http://example.com/order-received/1/'; }
		public function get_edit_order_url(): string           { return 'http://example.com/wp-admin/post.php?post=1'; }
		public function update_status( string $status, string $note = '' ): bool { $this->status = $status; return true; }
		public function add_order_note( string $note ): int    { return 1; }
		public function payment_complete( string $tx_id = '' ): void {}
		public function set_transaction_id( string $id ): void {}
		public function update_meta_data( string $key, mixed $val ): void { $this->meta[ $key ] = $val; }
		public function get_meta( string $key, bool $single = true ): mixed { return $this->meta[ $key ] ?? ''; }
		public function save(): int                            { return 1; }
		public function save_meta_data(): void {}
	}
}

// =========================================================================
// Load plugin classes under test
// =========================================================================

require_once dirname( __DIR__ ) . '/includes/class-wp-lunapay-api.php';
