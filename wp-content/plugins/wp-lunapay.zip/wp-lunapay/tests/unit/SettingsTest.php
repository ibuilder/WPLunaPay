<?php
declare(strict_types=1);

namespace WPLunaPay\Tests\Unit;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\Attributes\DataProvider;

/**
 * Tests for new gateway settings added in v1.0.0:
 *   - Minimum / maximum order amount validation
 *   - is_available() logic (min/max enforcement before checkout render)
 *   - iFrame height bounds
 *   - button_text default and override
 *   - show_icon toggle logic
 *   - success_message rendering
 *   - Sandbox vs live key prefix consistency
 */
class SettingsTest extends TestCase {

	// -------------------------------------------------------------------------
	// Minimum order amount
	// -------------------------------------------------------------------------

	#[Test]
	public function order_above_minimum_is_allowed(): void {
		$this->assertTrue( $this->amount_allowed( total: 100.00, min: 10.00, max: 0 ) );
	}

	#[Test]
	public function order_equal_to_minimum_is_allowed(): void {
		$this->assertTrue( $this->amount_allowed( total: 10.00, min: 10.00, max: 0 ) );
	}

	#[Test]
	public function order_below_minimum_is_blocked(): void {
		$this->assertFalse( $this->amount_allowed( total: 5.00, min: 10.00, max: 0 ) );
	}

	#[Test]
	public function zero_minimum_means_no_limit(): void {
		$this->assertTrue( $this->amount_allowed( total: 0.01, min: 0, max: 0 ) );
	}

	// -------------------------------------------------------------------------
	// Maximum order amount
	// -------------------------------------------------------------------------

	#[Test]
	public function order_below_maximum_is_allowed(): void {
		$this->assertTrue( $this->amount_allowed( total: 50.00, min: 0, max: 100.00 ) );
	}

	#[Test]
	public function order_equal_to_maximum_is_allowed(): void {
		$this->assertTrue( $this->amount_allowed( total: 100.00, min: 0, max: 100.00 ) );
	}

	#[Test]
	public function order_above_maximum_is_blocked(): void {
		$this->assertFalse( $this->amount_allowed( total: 150.00, min: 0, max: 100.00 ) );
	}

	#[Test]
	public function zero_maximum_means_no_limit(): void {
		$this->assertTrue( $this->amount_allowed( total: 999999.99, min: 0, max: 0 ) );
	}

	// -------------------------------------------------------------------------
	// Both min and max set
	// -------------------------------------------------------------------------

	#[Test]
	public function order_within_range_is_allowed(): void {
		$this->assertTrue( $this->amount_allowed( total: 50.00, min: 10.00, max: 100.00 ) );
	}

	#[Test]
	public function order_below_range_is_blocked(): void {
		$this->assertFalse( $this->amount_allowed( total: 5.00, min: 10.00, max: 100.00 ) );
	}

	#[Test]
	public function order_above_range_is_blocked(): void {
		$this->assertFalse( $this->amount_allowed( total: 200.00, min: 10.00, max: 100.00 ) );
	}

	#[Test]
	#[DataProvider('boundaryAmountProvider')]
	public function boundary_amounts( float $total, float $min, float $max, bool $expected ): void {
		$this->assertSame( $expected, $this->amount_allowed( $total, $min, $max ) );
	}

	public static function boundaryAmountProvider(): array {
		return [
			'exactly at min boundary'     => [ 10.00, 10.00, 100.00, true ],
			'exactly at max boundary'     => [ 100.00, 10.00, 100.00, true ],
			'one cent below min'          => [ 9.99, 10.00, 100.00, false ],
			'one cent above max'          => [ 100.01, 10.00, 100.00, false ],
			'no limits at all'            => [ 0.01, 0, 0, true ],
			'only min, above it'          => [ 50.00, 25.00, 0, true ],
			'only min, below it'          => [ 10.00, 25.00, 0, false ],
			'only max, below it'          => [ 10.00, 0, 25.00, true ],
			'only max, above it'          => [ 50.00, 0, 25.00, false ],
		];
	}

	// -------------------------------------------------------------------------
	// iFrame height bounds
	// -------------------------------------------------------------------------

	#[Test]
	public function iframe_height_clamped_to_minimum_300(): void {
		$height = $this->clamp_iframe_height( 100 );
		$this->assertSame( 300, $height );
	}

	#[Test]
	public function valid_iframe_height_passes_through(): void {
		$height = $this->clamp_iframe_height( 620 );
		$this->assertSame( 620, $height );
	}

	#[Test]
	public function zero_iframe_height_clamped_to_minimum(): void {
		$height = $this->clamp_iframe_height( 0 );
		$this->assertSame( 300, $height );
	}

	#[Test]
	public function negative_iframe_height_becomes_absolute_value(): void {
		// absint(-500) = 500, max(300, 500) = 500 — not clamped, absolute value taken
		$height = $this->clamp_iframe_height( -500 );
		$this->assertSame( 500, $height );
	}

	#[Test]
	public function small_negative_iframe_height_clamped_to_minimum(): void {
		// absint(-50) = 50, max(300, 50) = 300 — clamped because |value| < 300
		$height = $this->clamp_iframe_height( -50 );
		$this->assertSame( 300, $height );
	}

	#[Test]
	public function string_height_cast_correctly(): void {
		// absint('620') = 620
		$height = $this->clamp_iframe_height( \absint( '620' ) );
		$this->assertSame( 620, $height );
	}

	// -------------------------------------------------------------------------
	// button_text
	// -------------------------------------------------------------------------

	#[Test]
	public function default_button_text_contains_moonpay(): void {
		$default = 'Pay with Crypto (MoonPay)';
		$this->assertStringContainsString( 'MoonPay', $default );
	}

	#[Test]
	public function custom_button_text_replaces_default(): void {
		$custom = 'Complete Crypto Purchase';
		$text   = $this->get_button_text( $custom );
		$this->assertSame( 'Complete Crypto Purchase', $text );
	}

	#[Test]
	public function empty_button_text_falls_back_to_default(): void {
		$text = $this->get_button_text( '' );
		$this->assertSame( 'Pay with Crypto (MoonPay)', $text );
	}

	// -------------------------------------------------------------------------
	// show_icon
	// -------------------------------------------------------------------------

	#[Test]
	public function icon_shown_when_option_is_yes(): void {
		$icon = $this->resolve_icon( 'yes' );
		$this->assertNotEmpty( $icon, 'Icon URL should be non-empty when show_icon = yes' );
	}

	#[Test]
	public function icon_hidden_when_option_is_no(): void {
		$icon = $this->resolve_icon( 'no' );
		$this->assertSame( '', $icon, 'Icon should be empty string when show_icon = no' );
	}

	#[Test]
	public function icon_shown_by_default(): void {
		// Default is 'yes' — simulate missing option
		$icon = $this->resolve_icon( null );
		$this->assertNotEmpty( $icon );
	}

	// -------------------------------------------------------------------------
	// success_message
	// -------------------------------------------------------------------------

	#[Test]
	public function empty_success_message_produces_no_output(): void {
		$output = $this->render_success_message( '' );
		$this->assertSame( '', $output );
	}

	#[Test]
	public function non_empty_success_message_produces_output(): void {
		$output = $this->render_success_message( 'Thank you for your crypto payment!' );
		$this->assertStringContainsString( 'Thank you for your crypto payment!', $output );
	}

	#[Test]
	public function success_message_is_wrapped_in_notice_div(): void {
		$output = $this->render_success_message( 'Payment received.' );
		$this->assertStringContainsString( 'wp-lunapay-success-msg', $output );
	}

	// -------------------------------------------------------------------------
	// API key environment consistency
	// -------------------------------------------------------------------------

	#[Test]
	public function sandbox_keys_should_use_test_prefix(): void {
		$pub = 'pk_test_ABCDEF';
		$sec = 'sk_test_GHIJKL';

		$this->assertStringStartsWith( 'pk_test_', $pub );
		$this->assertStringStartsWith( 'sk_test_', $sec );
	}

	#[Test]
	public function live_keys_should_use_live_prefix(): void {
		$pub = 'pk_live_ABCDEF';
		$sec = 'sk_live_GHIJKL';

		$this->assertStringStartsWith( 'pk_live_', $pub );
		$this->assertStringStartsWith( 'sk_live_', $sec );
	}

	#[Test]
	public function sandbox_key_with_live_prefix_is_suspicious(): void {
		// Warn if sandbox mode is on but key looks like a live key
		$is_sandbox = true;
		$pub        = 'pk_live_ABCDEF';
		$mismatch   = $is_sandbox && str_starts_with( $pub, 'pk_live_' );

		$this->assertTrue( $mismatch, 'Should detect sandbox/live key mismatch' );
	}

	#[Test]
	public function live_key_with_test_prefix_is_suspicious(): void {
		$is_sandbox = false;
		$pub        = 'pk_test_ABCDEF';
		$mismatch   = ! $is_sandbox && str_starts_with( $pub, 'pk_test_' );

		$this->assertTrue( $mismatch, 'Should detect live mode but test key mismatch' );
	}

	// -------------------------------------------------------------------------
	// Helpers — mirror exactly the logic in class-wp-lunapay.php
	// -------------------------------------------------------------------------

	/**
	 * Mirrors the is_available() min/max check (cart total portion).
	 */
	private function amount_allowed( float $total, float $min, float $max ): bool {
		if ( $min > 0 && $total < $min ) return false;
		if ( $max > 0 && $total > $max ) return false;
		return true;
	}

	/**
	 * Mirrors: max(300, absint($this->get_option('iframe_height', '620')))
	 */
	private function clamp_iframe_height( int $raw ): int {
		return max( 300, \absint( $raw ) );
	}

	/**
	 * Mirrors: $this->get_option('button_text', default)
	 */
	private function get_button_text( string $option_value ): string {
		$default = 'Pay with Crypto (MoonPay)';
		return ! empty( $option_value ) ? $option_value : $default;
	}

	/**
	 * Mirrors: icon empty-string when show_icon !== 'yes'
	 */
	private function resolve_icon( ?string $option_value ): string {
		$base_icon = 'https://example.com/moonpay-logo.svg';
		$setting   = $option_value ?? 'yes'; // default is 'yes'
		return $setting === 'yes' ? $base_icon : '';
	}

	/**
	 * Mirrors: thankyou_page() success message rendering
	 */
	private function render_success_message( string $message ): string {
		if ( empty( $message ) ) {
			return '';
		}
		// wpautop converts \n to <p>, strip_tags simulated here
		$processed = '<p>' . htmlspecialchars( $message ) . '</p>';
		return '<div class="woocommerce-notice woocommerce-notice--success wp-lunapay-success-msg">'
		       . $processed
		       . '</div>';
	}
}
