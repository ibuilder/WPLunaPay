<?php
declare(strict_types=1);

namespace WPLunaPay\Tests\Unit;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\Attributes\DataProvider;
use WP_LunaPay_API;

/**
 * Tests for gateway-level logic that can be exercised without a full WP stack.
 *
 * Covers: color code handling, currency code sanitisation, externalTransactionId
 * format, process_payment guard conditions, and widget URL param correctness.
 */
class GatewayTest extends TestCase {

	// -------------------------------------------------------------------------
	// colorCode → widget URL encoding pipeline
	// The gateway does: ltrim($color, '#') then passes '#' . $color to the API.
	// The API passes it through http_build_query(RFC3986) which encodes # → %23.
	// -------------------------------------------------------------------------

	#[Test]
	public function gateway_color_pipeline_produces_single_encoded_hash(): void {
		// Simulate exactly what get_widget_url_for_order() does:
		$raw_option = '#7B3FE4';                       // stored in WC options
		$stripped   = ltrim( $raw_option, '#' );       // '7B3FE4'
		$for_api    = '#' . $stripped;                 // '#7B3FE4'  (re-add #)

		// Now pass to API and verify URL encoding
		$api = new WP_LunaPay_API( 'pk_test_xxx', 'sk_test_yyy', true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth', 'colorCode' => $for_api ] );

		$this->assertStringContainsString( 'colorCode=%237B3FE4', $url );
		$this->assertStringNotContainsString( '%2523', $url );
	}

	#[Test]
	#[DataProvider('colorCodeProvider')]
	public function various_color_codes_encode_correctly( string $input, string $expected_in_url ): void {
		$api = new WP_LunaPay_API( 'pk_test_xxx', 'sk_test_yyy', true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth', 'colorCode' => $input ] );

		$this->assertStringContainsString( $expected_in_url, $url );
	}

	public static function colorCodeProvider(): array {
		return [
			'purple'     => [ '#7B3FE4', 'colorCode=%237B3FE4' ],
			'black'      => [ '#000000', 'colorCode=%23000000' ],
			'white'      => [ '#FFFFFF', 'colorCode=%23FFFFFF' ],
			'shorthand'  => [ '#FFF',    'colorCode=%23FFF' ],
			'no hash'    => [ '7B3FE4',  'colorCode=7B3FE4' ],   // no # = no encoding needed
		];
	}

	// -------------------------------------------------------------------------
	// externalTransactionId format
	// Must be parseable by the webhook regex /^order_(\d+)_/
	// -------------------------------------------------------------------------

	#[Test]
	public function external_transaction_id_is_parseable_by_webhook_regex(): void {
		$order_id  = 42;
		$order_key = 'wc_order_AbCdEfGh';
		$ext_id    = 'order_' . $order_id . '_' . $order_key;

		$this->assertMatchesRegularExpression( '/^order_(\d+)_/', $ext_id );
		preg_match( '/^order_(\d+)_/', $ext_id, $matches );
		$this->assertSame( $order_id, (int) $matches[1] );
	}

	#[Test]
	#[DataProvider('orderIdProvider')]
	public function external_transaction_id_round_trips_order_id( int $order_id ): void {
		$ext_id = 'order_' . $order_id . '_wc_order_TestKey123';
		preg_match( '/^order_(\d+)_/', $ext_id, $matches );
		$this->assertSame( $order_id, (int) ( $matches[1] ?? 0 ) );
	}

	public static function orderIdProvider(): array {
		return [
			'single digit'  => [ 1 ],
			'double digit'  => [ 42 ],
			'large id'      => [ 999999 ],
			'medium id'     => [ 1234 ],
		];
	}

	// -------------------------------------------------------------------------
	// API keys guard — process_payment should fail when keys are empty
	// We test the guard condition logic directly (not the gateway class itself
	// which requires a full WC stack).
	// -------------------------------------------------------------------------

	#[Test]
	public function empty_publishable_key_triggers_guard(): void {
		$this->assertTrue( $this->keys_missing( '', 'sk_test_xxx' ) );
	}

	#[Test]
	public function empty_secret_key_triggers_guard(): void {
		$this->assertTrue( $this->keys_missing( 'pk_test_xxx', '' ) );
	}

	#[Test]
	public function both_keys_present_passes_guard(): void {
		$this->assertFalse( $this->keys_missing( 'pk_test_xxx', 'sk_test_yyy' ) );
	}

	#[Test]
	public function whitespace_only_key_triggers_guard(): void {
		$this->assertTrue( $this->keys_missing( '   ', 'sk_test_yyy' ) );
	}

	// -------------------------------------------------------------------------
	// Key format validation (mirrors validate_api_keys logic)
	// -------------------------------------------------------------------------

	#[Test]
	#[DataProvider('validKeyProvider')]
	public function valid_keys_pass_format_check( string $pub, string $sec ): void {
		$this->assertFalse( $this->key_format_invalid( $pub, $sec ) );
	}

	#[Test]
	#[DataProvider('invalidKeyProvider')]
	public function invalid_keys_fail_format_check( string $pub, string $sec ): void {
		$this->assertTrue( $this->key_format_invalid( $pub, $sec ) );
	}

	public static function validKeyProvider(): array {
		return [
			'sandbox keys' => [ 'pk_test_ABCDEF', 'sk_test_GHIJKL' ],
			'live keys'    => [ 'pk_live_ABCDEF', 'sk_live_GHIJKL' ],
		];
	}

	public static function invalidKeyProvider(): array {
		return [
			'pub has no pk_ prefix'    => [ 'ABCDEF', 'sk_test_GHIJKL' ],
			'sec has no sk_ prefix'    => [ 'pk_test_ABCDEF', 'GHIJKL' ],
			'both wrong prefix'        => [ 'api_key_ABCDEF', 'api_secret_GHIJKL' ],
			'pub is sec format'        => [ 'sk_test_ABCDEF', 'sk_test_GHIJKL' ],
		];
	}

	// -------------------------------------------------------------------------
	// Allowed currencies sanitisation
	// -------------------------------------------------------------------------

	#[Test]
	public function allowed_cryptos_comma_list_sanitises_codes(): void {
		$raw    = 'eth,btc,usdc,usdc_polygon';
		$codes  = array_map( 'sanitize_key', explode( ',', $raw ) );
		$result = implode( ',', array_filter( $codes ) );

		$this->assertSame( 'eth,btc,usdc,usdc_polygon', $result );
	}

	#[Test]
	public function allowed_cryptos_strips_spaces_and_invalid_chars(): void {
		$raw    = ' eth , BTC , USDC! ';
		$codes  = array_map( 'sanitize_key', explode( ',', $raw ) );
		$result = implode( ',', array_filter( $codes ) );

		// sanitize_key lowercases, strips spaces and special chars
		$this->assertSame( 'eth,btc,usdc', $result );
	}

	#[Test]
	public function empty_allowed_cryptos_returns_empty(): void {
		$raw    = '';
		$codes  = array_map( 'sanitize_key', explode( ',', $raw ) );
		$result = implode( ',', array_filter( $codes ) );

		$this->assertSame( '', $result );
	}

	// -------------------------------------------------------------------------
	// Helpers (mirror gateway logic exactly)
	// -------------------------------------------------------------------------

	private function keys_missing( string $pub, string $sec ): bool {
		return empty( trim( $pub ) ) || empty( trim( $sec ) );
	}

	private function key_format_invalid( string $pub, string $sec ): bool {
		return ! str_starts_with( $pub, 'pk_' ) || ! str_starts_with( $sec, 'sk_' );
	}
}
