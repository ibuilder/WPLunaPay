<?php
declare(strict_types=1);

namespace WPLunaPay\Tests\Unit;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\Attributes\DataProvider;

/**
 * Tests for shortcode attribute defaults, sanitisation, and
 * price ticker caching logic.
 *
 * We test the logic patterns used in WP_LunaPay_Shortcodes in isolation
 * (no WordPress shortcode registration needed).
 */
class ShortcodeTest extends TestCase {

	// -------------------------------------------------------------------------
	// [moonpay_buy] attribute defaults and sanitisation
	// -------------------------------------------------------------------------

	#[Test]
	public function buy_shortcode_defaults_mode_to_iframe(): void {
		$atts = $this->merge_buy_defaults( [] );
		$this->assertSame( 'iframe', $atts['mode'] );
	}

	#[Test]
	public function buy_shortcode_defaults_currency_to_eth(): void {
		$atts = $this->merge_buy_defaults( [] );
		$this->assertSame( 'eth', $atts['currency'] );
	}

	#[Test]
	public function buy_shortcode_defaults_height_to_600(): void {
		$atts = $this->merge_buy_defaults( [] );
		$this->assertSame( '600', $atts['height'] );
	}

	#[Test]
	public function buy_shortcode_accepts_custom_currency(): void {
		$atts = $this->merge_buy_defaults( [ 'currency' => 'btc' ] );
		$this->assertSame( 'btc', $atts['currency'] );
	}

	#[Test]
	public function buy_shortcode_mode_sanitised_as_key(): void {
		// sanitize_key lowercases and strips special chars
		$mode = sanitize_key( 'iFrame' );
		$this->assertSame( 'iframe', $mode );
	}

	#[Test]
	public function buy_shortcode_height_is_integer(): void {
		$atts   = $this->merge_buy_defaults( [ 'height' => '500' ] );
		$height = \absint( $atts['height'] );
		$this->assertSame( 500, $height );
	}

	#[Test]
	public function buy_shortcode_height_defaults_to_600_when_invalid(): void {
		$atts   = $this->merge_buy_defaults( [ 'height' => 'invalid' ] );
		$height = \absint( $atts['height'] );
		// absint('invalid') = 0, we fall back to 600
		$fallback = $height > 0 ? $height : 600;
		$this->assertSame( 600, $fallback );
	}

	// -------------------------------------------------------------------------
	// [moonpay_crypto_price] attribute sanitisation
	// -------------------------------------------------------------------------

	#[Test]
	#[DataProvider('currencyCodeProvider')]
	public function price_ticker_currency_is_lowercased_and_sanitised( string $input, string $expected ): void {
		$result = strtolower( sanitize_key( $input ) );
		$this->assertSame( $expected, $result );
	}

	public static function currencyCodeProvider(): array {
		return [
			'lowercase eth' => [ 'eth',  'eth' ],
			'uppercase ETH' => [ 'ETH',  'eth' ],
			'mixed BtC'     => [ 'BtC',  'btc' ],
			'with space'    => [ ' eth', 'eth' ],
			'usdc_polygon'  => [ 'usdc_polygon', 'usdc_polygon' ],
		];
	}

	// -------------------------------------------------------------------------
	// Price AJAX — transient cache key format
	// -------------------------------------------------------------------------

	#[Test]
	public function price_cache_key_format_is_consistent(): void {
		$currency  = 'eth';
		$fiat      = 'usd';
		$cache_key = 'wp_lunapay_price_' . $currency . '_' . $fiat;

		$this->assertSame( 'wp_lunapay_price_eth_usd', $cache_key );
	}

	#[Test]
	public function price_cache_key_differs_by_currency(): void {
		$key_eth = 'wp_lunapay_price_eth_usd';
		$key_btc = 'wp_lunapay_price_btc_usd';

		$this->assertNotSame( $key_eth, $key_btc );
	}

	#[Test]
	public function price_cache_key_differs_by_fiat(): void {
		$key_usd = 'wp_lunapay_price_eth_usd';
		$key_eur = 'wp_lunapay_price_eth_eur';

		$this->assertNotSame( $key_usd, $key_eur );
	}

	// -------------------------------------------------------------------------
	// Price AJAX — input length validation (guards against abuse)
	// -------------------------------------------------------------------------

	#[Test]
	public function short_currency_code_passes_length_check(): void {
		$this->assertFalse( $this->price_input_too_long( 'eth', 'usd' ) );
	}

	#[Test]
	public function long_currency_code_fails_length_check(): void {
		$this->assertTrue( $this->price_input_too_long( str_repeat( 'a', 31 ), 'usd' ) );
	}

	#[Test]
	public function long_fiat_code_fails_length_check(): void {
		$this->assertTrue( $this->price_input_too_long( 'eth', str_repeat( 'x', 11 ) ) );
	}

	#[Test]
	public function boundary_currency_length_passes(): void {
		$this->assertFalse( $this->price_input_too_long( str_repeat( 'a', 30 ), 'usd' ) );
	}

	#[Test]
	public function boundary_fiat_length_passes(): void {
		$this->assertFalse( $this->price_input_too_long( 'eth', str_repeat( 'x', 10 ) ) );
	}

	// -------------------------------------------------------------------------
	// [moonpay_order_status] — order ownership check logic
	// -------------------------------------------------------------------------

	#[Test]
	public function admin_can_see_any_order_status(): void {
		$can_see = $this->can_see_order_status(
			customer_id:    5,
			current_user:   0,
			is_admin:       true
		);
		$this->assertTrue( $can_see );
	}

	#[Test]
	public function order_owner_can_see_their_own_status(): void {
		$can_see = $this->can_see_order_status(
			customer_id:  5,
			current_user: 5,
			is_admin:     false
		);
		$this->assertTrue( $can_see );
	}

	#[Test]
	public function other_user_cannot_see_order_status(): void {
		$can_see = $this->can_see_order_status(
			customer_id:  5,
			current_user: 99,
			is_admin:     false
		);
		$this->assertFalse( $can_see );
	}

	#[Test]
	public function guest_cannot_see_order_status(): void {
		$can_see = $this->can_see_order_status(
			customer_id:  5,
			current_user: 0,
			is_admin:     false
		);
		$this->assertFalse( $can_see );
	}

	// -------------------------------------------------------------------------
	// Helpers (mirror shortcode logic exactly)
	// -------------------------------------------------------------------------

	private function merge_buy_defaults( array $atts ): array {
		return array_merge( [
			'currency' => 'eth',
			'amount'   => '',
			'fiat'     => 'usd',
			'mode'     => 'iframe',
			'height'   => '600',
			'width'    => '100%',
			'class'    => '',
		], $atts );
	}

	private function price_input_too_long( string $currency, string $fiat ): bool {
		return strlen( $currency ) > 30 || strlen( $fiat ) > 10;
	}

	private function can_see_order_status( int $customer_id, int $current_user, bool $is_admin ): bool {
		return $is_admin || ( $current_user !== 0 && $current_user === $customer_id );
	}
}
