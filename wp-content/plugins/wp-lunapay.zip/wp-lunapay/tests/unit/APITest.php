<?php
declare(strict_types=1);

namespace WPLunaPay\Tests\Unit;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\Attributes\DataProvider;
use WP_LunaPay_API;

/**
 * Tests for WP_LunaPay_API
 *
 * Covers: HMAC signing, widget URL construction, signature verification,
 *         sandbox/live URL selection, colorCode encoding correctness.
 */
class APITest extends TestCase {

	private const PUB_KEY    = 'pk_test_PUBLICKEY123';
	private const SEC_KEY    = 'sk_test_SECRETKEY456';
	private const LIVE_PUB   = 'pk_live_PUBLICKEY123';
	private const LIVE_SEC   = 'sk_live_SECRETKEY456';

	// -------------------------------------------------------------------------
	// sign()
	// -------------------------------------------------------------------------

	#[Test]
	public function sign_produces_hmac_sha256_base64(): void {
		$api    = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );
		$input  = '?apiKey=pk_test_PUBLICKEY123&currencyCode=eth';
		$result = $api->sign( $input );

		$expected = base64_encode( hash_hmac( 'sha256', $input, self::SEC_KEY, true ) );

		$this->assertSame( $expected, $result );
	}

	#[Test]
	public function sign_returns_base64_string(): void {
		$api    = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );
		$result = $api->sign( '?test=1' );

		$this->assertMatchesRegularExpression( '/^[A-Za-z0-9+\/]+=*$/', $result );
	}

	#[Test]
	public function sign_changes_with_different_secret_key(): void {
		$api1 = new WP_LunaPay_API( self::PUB_KEY, 'sk_test_KEY_ONE' );
		$api2 = new WP_LunaPay_API( self::PUB_KEY, 'sk_test_KEY_TWO' );

		$this->assertNotSame( $api1->sign( '?q=1' ), $api2->sign( '?q=1' ) );
	}

	#[Test]
	public function sign_changes_with_different_input(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );

		$this->assertNotSame( $api->sign( '?a=1' ), $api->sign( '?a=2' ) );
	}

	// -------------------------------------------------------------------------
	// verify_webhook_signature()
	// -------------------------------------------------------------------------

	#[Test]
	public function verify_webhook_signature_returns_true_for_correct_signature(): void {
		$api     = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );
		$payload = '{"type":"transaction_updated","data":{"status":"completed"}}';
		$sig     = base64_encode( hash_hmac( 'sha256', $payload, self::SEC_KEY, true ) );

		$this->assertTrue( $api->verify_webhook_signature( $payload, $sig ) );
	}

	#[Test]
	public function verify_webhook_signature_returns_false_for_tampered_payload(): void {
		$api     = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );
		$payload = '{"type":"transaction_updated","data":{"status":"completed"}}';
		$sig     = base64_encode( hash_hmac( 'sha256', $payload, self::SEC_KEY, true ) );

		$tampered = '{"type":"transaction_updated","data":{"status":"failed"}}';

		$this->assertFalse( $api->verify_webhook_signature( $tampered, $sig ) );
	}

	#[Test]
	public function verify_webhook_signature_returns_false_for_wrong_secret(): void {
		$api_sign   = new WP_LunaPay_API( self::PUB_KEY, 'sk_test_CORRECT' );
		$api_verify = new WP_LunaPay_API( self::PUB_KEY, 'sk_test_WRONG' );
		$payload    = '{"status":"completed"}';
		$sig        = base64_encode( hash_hmac( 'sha256', $payload, 'sk_test_CORRECT', true ) );

		$this->assertFalse( $api_verify->verify_webhook_signature( $payload, $sig ) );
	}

	#[Test]
	public function verify_webhook_signature_returns_false_for_empty_signature(): void {
		$api     = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );
		$payload = '{"status":"completed"}';

		$this->assertFalse( $api->verify_webhook_signature( $payload, '' ) );
	}

	#[Test]
	public function verify_webhook_signature_returns_false_for_garbage_signature(): void {
		$api     = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY );
		$payload = '{"status":"completed"}';

		$this->assertFalse( $api->verify_webhook_signature( $payload, 'not-a-valid-signature' ) );
	}

	// -------------------------------------------------------------------------
	// get_widget_url() — URL structure
	// -------------------------------------------------------------------------

	#[Test]
	public function get_widget_url_uses_sandbox_base_in_sandbox_mode(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth' ] );

		$this->assertStringStartsWith( 'https://buy-sandbox.moonpay.com', $url );
	}

	#[Test]
	public function get_widget_url_uses_live_base_in_live_mode(): void {
		$api = new WP_LunaPay_API( self::LIVE_PUB, self::LIVE_SEC, false );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth' ] );

		$this->assertStringStartsWith( 'https://buy.moonpay.com', $url );
	}

	#[Test]
	public function get_widget_url_includes_api_key(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth' ] );

		$this->assertStringContainsString( 'apiKey=' . self::PUB_KEY, $url );
	}

	#[Test]
	public function get_widget_url_includes_signature_parameter(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth' ] );

		$this->assertStringContainsString( '&signature=', $url );
	}

	#[Test]
	public function get_widget_url_signature_is_last_parameter(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth', 'baseCurrencyCode' => 'usd' ] );

		// Signature must be appended after all other params so it covers the full query string
		$this->assertStringContainsString( '&signature=', $url );
		$sig_pos = strpos( $url, '&signature=' );
		$this->assertFalse(
			strpos( $url, '&', (int) $sig_pos + 1 ) !== false && strpos( $url, '=', (int) $sig_pos + 1 ),
			'No additional query params should follow the signature'
		);
	}

	#[Test]
	public function get_widget_url_signature_is_valid_for_the_url(): void {
		$api    = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$params = [ 'currencyCode' => 'eth', 'baseCurrencyCode' => 'usd' ];
		$url    = $api->get_widget_url( $params );

		// Extract the query string without &signature= and verify the sig matches
		$base        = 'https://buy-sandbox.moonpay.com';
		$after_base  = substr( $url, strlen( $base ) ); // ?apiKey=...&signature=XXXXX
		$sig_offset  = strrpos( $after_base, '&signature=' );
		$query_part  = substr( $after_base, 0, $sig_offset );          // ?apiKey=...
		$encoded_sig = substr( $after_base, $sig_offset + strlen( '&signature=' ) );
		$raw_sig     = rawurldecode( $encoded_sig );

		$expected_sig = $api->sign( $query_part );
		$this->assertSame( $expected_sig, $raw_sig, 'Signature must match HMAC of the query string' );
	}

	#[Test]
	public function get_widget_url_includes_passed_params(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [
			'currencyCode'     => 'btc',
			'baseCurrencyCode' => 'usd',
			'baseCurrencyAmount' => 50.00,
		] );

		$this->assertStringContainsString( 'currencyCode=btc', $url );
		$this->assertStringContainsString( 'baseCurrencyCode=usd', $url );
		$this->assertStringContainsString( 'baseCurrencyAmount=50', $url );
	}

	// -------------------------------------------------------------------------
	// colorCode encoding — regression test for the double-encoding bug
	// -------------------------------------------------------------------------

	#[Test]
	public function color_code_is_encoded_once_not_twice(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [
			'currencyCode' => 'eth',
			'colorCode'    => '#7B3FE4',  // raw # should become %23 exactly once
		] );

		// Must contain the single-encoded form
		$this->assertStringContainsString(
			'colorCode=%237B3FE4',
			$url,
			'# should be encoded to %23 (single encoding)'
		);

		// Must NOT contain the double-encoded form (the previous bug)
		$this->assertStringNotContainsString(
			'%25237B3FE4',
			$url,
			'Double-encoding %2523 must not be present'
		);
	}

	#[Test]
	public function color_code_without_hash_is_still_valid(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		// Passing without # prefix (e.g. if stored value had # stripped by ltrim)
		$url = $api->get_widget_url( [
			'currencyCode' => 'eth',
			'colorCode'    => '7B3FE4',
		] );

		// No # → no encoding needed → appears as-is
		$this->assertStringContainsString( 'colorCode=7B3FE4', $url );
		$this->assertStringNotContainsString( 'colorCode=%237B3FE4', $url );
	}

	// -------------------------------------------------------------------------
	// Different currencies and fiat codes
	// -------------------------------------------------------------------------

	#[Test]
	#[DataProvider('currencyProvider')]
	public function get_widget_url_works_with_various_currencies( string $crypto, string $fiat ): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [
			'currencyCode'     => $crypto,
			'baseCurrencyCode' => $fiat,
		] );

		$this->assertStringContainsString( 'currencyCode=' . $crypto, $url );
		$this->assertStringContainsString( 'baseCurrencyCode=' . $fiat, $url );
		$this->assertStringContainsString( '&signature=', $url );
	}

	public static function currencyProvider(): array {
		return [
			'ETH/USD'          => [ 'eth', 'usd' ],
			'BTC/GBP'          => [ 'btc', 'gbp' ],
			'USDC/EUR'         => [ 'usdc', 'eur' ],
			'USDC_Polygon/USD' => [ 'usdc_polygon', 'usd' ],
		];
	}

	// -------------------------------------------------------------------------
	// Signature uses RFC3986 encoding (spaces → %20, not +)
	// -------------------------------------------------------------------------

	#[Test]
	public function query_string_uses_rfc3986_encoding(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [
			'currencyCode' => 'eth',
			'email'        => 'test+user@example.com',
		] );

		// RFC3986: + in email should be encoded as %2B not left as +
		$this->assertStringContainsString( 'test%2Buser%40example.com', $url );
		// Should not use the old + encoding for spaces/special chars
		$this->assertStringNotContainsString( 'test+user', $url );
	}

	// -------------------------------------------------------------------------
	// API key exposed in URL
	// -------------------------------------------------------------------------

	#[Test]
	public function secret_key_is_not_in_widget_url(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth' ] );

		$this->assertStringNotContainsString( self::SEC_KEY, $url, 'Secret key must never appear in the widget URL' );
	}

	#[Test]
	public function publishable_key_is_in_widget_url(): void {
		$api = new WP_LunaPay_API( self::PUB_KEY, self::SEC_KEY, true );
		$url = $api->get_widget_url( [ 'currencyCode' => 'eth' ] );

		$this->assertStringContainsString( self::PUB_KEY, $url );
	}
}
