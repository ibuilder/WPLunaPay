<?php
declare(strict_types=1);

namespace WPLunaPay\Tests\Unit;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\Attributes\DataProvider;

/**
 * Tests for webhook-related logic.
 *
 * We test the pure PHP patterns extracted from WP_LunaPay_Webhook:
 *   - External transaction ID parsing (the regex)
 *   - Status string normalisation
 *   - Duplicate-delivery guard logic
 */
class WebhookTest extends TestCase {

	// -------------------------------------------------------------------------
	// External transaction ID regex:  /^order_(\d+)_/
	// -------------------------------------------------------------------------

	#[Test]
	public function regex_extracts_order_id_from_standard_external_id(): void {
		$external_id = 'order_123_wc_order_AbCdEfGhIj';
		$this->assertSame( 123, $this->parse_order_id( $external_id ) );
	}

	#[Test]
	public function regex_extracts_order_id_with_large_id(): void {
		$external_id = 'order_99999_wc_order_XyZ';
		$this->assertSame( 99999, $this->parse_order_id( $external_id ) );
	}

	#[Test]
	public function regex_extracts_order_id_with_single_digit(): void {
		$external_id = 'order_1_wc_order_AbCd';
		$this->assertSame( 1, $this->parse_order_id( $external_id ) );
	}

	#[Test]
	public function regex_handles_underscore_in_order_key(): void {
		// Order keys like wc_order_XXXX contain underscores — must not confuse the regex
		$external_id = 'order_456_wc_order_abc_def_ghi';
		$this->assertSame( 456, $this->parse_order_id( $external_id ) );
	}

	#[Test]
	#[DataProvider('invalidExternalIdProvider')]
	public function regex_returns_zero_for_invalid_external_id( string $external_id ): void {
		$this->assertSame( 0, $this->parse_order_id( $external_id ) );
	}

	public static function invalidExternalIdProvider(): array {
		return [
			'empty string'           => [ '' ],
			'no order prefix'        => [ 'transaction_123_xyz' ],
			'no digits after order_' => [ 'order__wc_order_abc' ],
			'letters instead of id'  => [ 'order_abc_wc_order_xyz' ],
			'missing trailing _'     => [ 'order_123' ],
			'random string'          => [ 'something_completely_different' ],
		];
	}

	// -------------------------------------------------------------------------
	// Status string normalisation
	// wc_get_order_statuses() keys include 'wc-' prefix; gateway option stores them
	// with the prefix; process_event strips it before calling update_status().
	// -------------------------------------------------------------------------

	#[Test]
	public function wc_prefix_stripped_from_pending_status(): void {
		$this->assertSame( 'pending', $this->strip_wc_prefix( 'wc-pending' ) );
	}

	#[Test]
	public function wc_prefix_stripped_from_processing_status(): void {
		$this->assertSame( 'processing', $this->strip_wc_prefix( 'wc-processing' ) );
	}

	#[Test]
	public function wc_prefix_stripped_from_failed_status(): void {
		$this->assertSame( 'failed', $this->strip_wc_prefix( 'wc-failed' ) );
	}

	#[Test]
	public function wc_prefix_strip_is_idempotent_when_no_prefix(): void {
		// If the option was saved without the wc- prefix, stripping should be a no-op
		$this->assertSame( 'pending', $this->strip_wc_prefix( 'pending' ) );
	}

	// -------------------------------------------------------------------------
	// Duplicate-delivery guard
	// Only restore stock if order is not already in a terminal state.
	// -------------------------------------------------------------------------

	#[Test]
	public function stock_is_restored_for_pending_order_on_failure(): void {
		$should_restore = $this->should_restore_stock( 'pending' );
		$this->assertTrue( $should_restore );
	}

	#[Test]
	public function stock_is_not_restored_for_already_cancelled_order(): void {
		$should_restore = $this->should_restore_stock( 'cancelled' );
		$this->assertFalse( $should_restore );
	}

	#[Test]
	public function stock_is_not_restored_for_already_failed_order(): void {
		$should_restore = $this->should_restore_stock( 'failed' );
		$this->assertFalse( $should_restore );
	}

	#[Test]
	public function stock_is_restored_for_processing_order_on_failure(): void {
		// Edge case: if somehow processing order receives a 'failed' webhook
		$should_restore = $this->should_restore_stock( 'processing' );
		$this->assertTrue( $should_restore );
	}

	// -------------------------------------------------------------------------
	// Webhook signature verification (via API class)
	// -------------------------------------------------------------------------

	#[Test]
	public function webhook_signature_verified_correctly_end_to_end(): void {
		$sec_key = 'sk_test_webhook_secret_key';
		$payload = json_encode( [
			'type' => 'transaction_updated',
			'data' => [ 'status' => 'completed', 'id' => 'tx_abc123' ],
		] );

		// Simulate MoonPay signing the payload
		$correct_sig = base64_encode( hash_hmac( 'sha256', $payload, $sec_key, true ) );

		$api = new \WP_LunaPay_API( 'pk_test_xxx', $sec_key, true );

		$this->assertTrue(  $api->verify_webhook_signature( $payload, $correct_sig ) );
		$this->assertFalse( $api->verify_webhook_signature( $payload, 'bad_signature' ) );
		$this->assertFalse( $api->verify_webhook_signature( $payload . ' ', $correct_sig ) ); // tampered
	}

	// -------------------------------------------------------------------------
	// Helpers (mirrors the exact logic in WP_LunaPay_Webhook::process_event)
	// -------------------------------------------------------------------------

	private function parse_order_id( string $external_id ): int {
		if ( ! preg_match( '/^order_(\d+)_/', $external_id, $matches ) ) {
			return 0;
		}
		return (int) $matches[1];
	}

	private function strip_wc_prefix( string $status ): string {
		return str_replace( 'wc-', '', $status );
	}

	private function should_restore_stock( string $current_order_status ): bool {
		return ! in_array( $current_order_status, [ 'cancelled', 'failed' ], true );
	}
}
